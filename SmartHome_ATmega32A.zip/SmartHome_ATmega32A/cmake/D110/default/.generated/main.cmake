include("${CMAKE_CURRENT_LIST_DIR}/rule.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/file.cmake")

set(D110_default_library_list )

# Handle files with suffix (s|as|asm|AS|ASM|As|aS|Asm), for group default-XC8
if(D110_default_default_XC8_FILE_TYPE_assemble)
add_library(D110_default_default_XC8_assemble OBJECT ${D110_default_default_XC8_FILE_TYPE_assemble})
    D110_default_default_XC8_assemble_rule(D110_default_default_XC8_assemble)
    list(APPEND D110_default_library_list "$<TARGET_OBJECTS:D110_default_default_XC8_assemble>")

endif()

# Handle files with suffix S, for group default-XC8
if(D110_default_default_XC8_FILE_TYPE_assemblePreprocess)
add_library(D110_default_default_XC8_assemblePreprocess OBJECT ${D110_default_default_XC8_FILE_TYPE_assemblePreprocess})
    D110_default_default_XC8_assemblePreprocess_rule(D110_default_default_XC8_assemblePreprocess)
    list(APPEND D110_default_library_list "$<TARGET_OBJECTS:D110_default_default_XC8_assemblePreprocess>")

endif()

# Handle files with suffix [cC], for group default-XC8
if(D110_default_default_XC8_FILE_TYPE_compile)
add_library(D110_default_default_XC8_compile OBJECT ${D110_default_default_XC8_FILE_TYPE_compile})
    D110_default_default_XC8_compile_rule(D110_default_default_XC8_compile)
    list(APPEND D110_default_library_list "$<TARGET_OBJECTS:D110_default_default_XC8_compile>")

endif()

# Handle files with suffix elf, for group default-XC8
if(D110_default_default_XC8_FILE_TYPE_objcopy_avr)
add_library(D110_default_default_XC8_objcopy_avr OBJECT ${D110_default_default_XC8_FILE_TYPE_objcopy_avr})
    D110_default_default_XC8_objcopy_avr_rule(D110_default_default_XC8_objcopy_avr)
    list(APPEND D110_default_library_list "$<TARGET_OBJECTS:D110_default_default_XC8_objcopy_avr>")

endif()


# Main target for this project
add_executable(D110_default_image_1zUiuQGX ${D110_default_library_list})

set_target_properties(D110_default_image_1zUiuQGX PROPERTIES
    OUTPUT_NAME "default"
    SUFFIX ".elf"
    ADDITIONAL_CLEAN_FILES "${output_extensions}"
    RUNTIME_OUTPUT_DIRECTORY "${D110_default_output_dir}")
target_link_libraries(D110_default_image_1zUiuQGX PRIVATE ${D110_default_default_XC8_FILE_TYPE_link})
# Add the link options from the rule file.
D110_default_link_rule( D110_default_image_1zUiuQGX)


#Add objcopy steps
D110_default_objcopy_avr_rule(D110_default_image_1zUiuQGX)

