# The following variables contains the files used by the different stages of the build process.
set(SmartHome_default_default_XC8_FILE_TYPE_assemble)
set_source_files_properties(${SmartHome_default_default_XC8_FILE_TYPE_assemble} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${SmartHome_default_default_XC8_FILE_TYPE_assemble})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(SmartHome_default_default_XC8_FILE_TYPE_assemblePreprocess)
set_source_files_properties(${SmartHome_default_default_XC8_FILE_TYPE_assemblePreprocess} PROPERTIES LANGUAGE ASM)

# For assembly files, add "." to the include path for each file so that .include with a relative path works
foreach(source_file ${SmartHome_default_default_XC8_FILE_TYPE_assemblePreprocess})
        set_source_files_properties(${source_file} PROPERTIES INCLUDE_DIRECTORIES "$<PATH:NORMAL_PATH,$<PATH:REMOVE_FILENAME,${source_file}>>")
endforeach()

set(SmartHome_default_default_XC8_FILE_TYPE_compile
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/AC_CONTROL/AC_CONTROL.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/ALARM/ALARM.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/BT/BT.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/BUZZER/BUZZER.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/DIMMER/DIMMER.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/KEYPAD/KEYPAD.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/LCD/LCD.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/LEDS/LEDS.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/LIGHTS/LIGHTS.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/SEG/SEG.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/SERVO/SERVO.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/TEMP_SENSOR/TEMP_SENSOR.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../HAL/USER_STORE/USER_STORE.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../MCAL/ADC/ADC.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../MCAL/DIO/DIO.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../MCAL/GPIO/GPIO.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../MCAL/TIMER/TIMER.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../MCAL/UART/UART.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/../../../main.c")
set_source_files_properties(${SmartHome_default_default_XC8_FILE_TYPE_compile} PROPERTIES LANGUAGE C)
set(SmartHome_default_default_XC8_FILE_TYPE_link)
set(SmartHome_default_default_XC8_FILE_TYPE_objcopy_avr)
set(SmartHome_default_default_XC8_FILE_TYPE_objcopy_lss)
set(SmartHome_default_image_name "default.elf")
set(SmartHome_default_image_base_name "default")

# The output directory of the final image.
set(SmartHome_default_output_dir "${CMAKE_CURRENT_SOURCE_DIR}/../../../out/D110")

# The full path to the final image.
set(SmartHome_default_full_path_to_image ${SmartHome_default_output_dir}/${SmartHome_default_image_name})

# Potential output file extensions
set(output_extensions
    .hex
    .hxl
    .mum
    .o
    .sdb
    .sym
    .cmf)
list(TRANSFORM output_extensions PREPEND "${SmartHome_default_output_dir}/${SmartHome_default_image_base_name}")
