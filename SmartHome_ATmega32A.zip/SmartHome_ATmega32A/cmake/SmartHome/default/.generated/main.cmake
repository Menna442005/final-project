include("${CMAKE_CURRENT_LIST_DIR}/rule.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/file.cmake")

set(SmartHome_default_library_list )

set(OUTPUT_SUFFIX elf)
# Handle files with suffix (s|as|asm|AS|ASM|As|aS|Asm), for group default-XC8
if(SmartHome_default_default_XC8_FILE_TYPE_assemble)
add_library(SmartHome_default_default_XC8_assemble OBJECT ${SmartHome_default_default_XC8_FILE_TYPE_assemble})
    SmartHome_default_default_XC8_assemble_rule(SmartHome_default_default_XC8_assemble)
    list(APPEND SmartHome_default_library_list "$<TARGET_OBJECTS:SmartHome_default_default_XC8_assemble>")

endif()

# Handle files with suffix S, for group default-XC8
if(SmartHome_default_default_XC8_FILE_TYPE_assemblePreprocess)
add_library(SmartHome_default_default_XC8_assemblePreprocess OBJECT ${SmartHome_default_default_XC8_FILE_TYPE_assemblePreprocess})
    SmartHome_default_default_XC8_assemblePreprocess_rule(SmartHome_default_default_XC8_assemblePreprocess)
    list(APPEND SmartHome_default_library_list "$<TARGET_OBJECTS:SmartHome_default_default_XC8_assemblePreprocess>")

endif()

# Handle files with suffix [cC], for group default-XC8
if(SmartHome_default_default_XC8_FILE_TYPE_compile)
add_library(SmartHome_default_default_XC8_compile OBJECT ${SmartHome_default_default_XC8_FILE_TYPE_compile})
    SmartHome_default_default_XC8_compile_rule(SmartHome_default_default_XC8_compile)
    list(APPEND SmartHome_default_library_list "$<TARGET_OBJECTS:SmartHome_default_default_XC8_compile>")

endif()

# Handle files with suffix elf, for group default-XC8
if(SmartHome_default_default_XC8_FILE_TYPE_objcopy_avr)
add_library(SmartHome_default_default_XC8_objcopy_avr OBJECT ${SmartHome_default_default_XC8_FILE_TYPE_objcopy_avr})
    SmartHome_default_default_XC8_objcopy_avr_rule(SmartHome_default_default_XC8_objcopy_avr)
    list(APPEND SmartHome_default_library_list "$<TARGET_OBJECTS:SmartHome_default_default_XC8_objcopy_avr>")

endif()

# Handle files with suffix elf, for group default-XC8
if(SmartHome_default_default_XC8_FILE_TYPE_objcopy_lss)
add_library(SmartHome_default_default_XC8_objcopy_lss OBJECT ${SmartHome_default_default_XC8_FILE_TYPE_objcopy_lss})
    SmartHome_default_default_XC8_objcopy_lss_rule(SmartHome_default_default_XC8_objcopy_lss)
    list(APPEND SmartHome_default_library_list "$<TARGET_OBJECTS:SmartHome_default_default_XC8_objcopy_lss>")

endif()


# Main target for this project
add_executable(SmartHome_default_image_hyf3jCEt ${SmartHome_default_library_list})

set_target_properties(SmartHome_default_image_hyf3jCEt PROPERTIES
    OUTPUT_NAME "default"
    SUFFIX ".elf"
    ADDITIONAL_CLEAN_FILES "${output_extensions}"
    RUNTIME_OUTPUT_DIRECTORY "${SmartHome_default_output_dir}")
target_link_libraries(SmartHome_default_image_hyf3jCEt PRIVATE ${SmartHome_default_default_XC8_FILE_TYPE_link})
# Add the link options from the rule file.
SmartHome_default_link_rule( SmartHome_default_image_hyf3jCEt)


#Add objcopy steps
SmartHome_default_objcopy_avr_rule(SmartHome_default_image_hyf3jCEt)
SmartHome_default_objcopy_lss_rule(SmartHome_default_image_hyf3jCEt)

