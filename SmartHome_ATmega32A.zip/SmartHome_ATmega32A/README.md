# Smart Home Controller - ATmega32A

This project extends the supplied D110 AVR project and keeps its `HAL` / `MCAL`
layout and driver style. The target is ATmega32A at 16 MHz.

## First power-up

1. Open `SmartHome.code-workspace` in VS Code, or open this folder directly.
2. Build with the MPLAB for VS Code project configuration and XC8.
3. Program `out/D110/default.hex` onto the ATmega32A.
4. Connect a serial terminal or Bluetooth module at 9600 baud, 8 data bits, no
   parity, 1 stop bit. Send commands terminated by CR or LF.
5. The first boot initializes the ATmega32A's internal EEPROM.

Default credentials for a new/erased EEPROM:

- Remote administrator: username `admin`, password `1234`.
- Local keypad user PIN: `4567` (press SW4, SW5, SW6, SW7 in that order).

Change the remote account password with `PASS <new-password>` after logging in.
Usernames and passwords are limited to 11 characters and may not contain spaces.
The EEPROM holds the admin plus up to seven additional remote users.

## Bluetooth / serial commands

| Command | Permission | Result |
|---|---|---|
| `HELP` | Anyone | Shows command list |
| `LOGIN admin 1234` | Anyone | Starts an admin or user session |
| `ADD <name> <password>` | Admin | Stores a user in internal EEPROM |
| `DEL <name>` | Admin | Removes a user from internal EEPROM |
| `LIST` | Admin | Lists registered usernames |
| `PASS <new-password>` | Logged-in user | Changes the current account password |
| `LIGHT <1-5> <ON\|OFF>` | Logged-in user | Controls one on/off lamp |
| `DIM <0-100>` | Logged-in user | Sets the dimmer level in percent |
| `DOOR OPEN` / `DOOR CLOSE` | Admin | Moves the servo to the configured position |
| `LOCAL ENABLE` / `LOCAL DISABLE` | Admin | Enables or blocks local keypad control |
| `STATUS` | Logged-in user | Reports temperature and output states |
| `LOGOUT` | Anyone | Ends the remote session |

Admin is available only through Bluetooth/UART. When an admin logs in, local
keypad control is blocked until the admin sends `LOCAL ENABLE`. User sessions
do not block local user control. Users cannot operate the door.

Four consecutive failed local or remote logins latch the system and sound the
buzzer until the MCU is reset. The failed-attempt counter is volatile and is
cleared by reset.

## Local keypad

The local interface uses a separate four-digit PIN. After login:

- SW4 toggles lamp 1; SW5 toggles lamp 2; SW6 toggles lamp 3.
- SW7 toggles lamp 4; SW8 toggles lamp 5.
- SW9 advances the dimmer through 25%, 50%, 75%, 100%, and 0%.
- Door control is not available locally.
- Local access logs out after 60 seconds without a key press. SW1 also logs out
  when that key is available.

The supplied keypad driver maps rows to PA1..PA3 and columns to PD2, PD3, PD7.
The first three physical keys were reported not to read on the user's kit. The
default PIN and local controls above use SW4..SW9 so they remain demonstrable;
confirm the board's `KEYPAD_ON` switch and row-1 wiring before presenting all
nine keys as working.

## Temperature behavior

An LM35-compatible sensor is read on ADC0/PA0. The AC output turns on above
28 C, turns off below 21 C, and retains its previous state between those limits.
Connect the output through an appropriate transistor/relay driver; do not
connect a motor directly to an MCU pin.

## I/O map

| Function | ATmega32A pin | Notes |
|---|---|---|
| LCD RS / EN | PB1 / PB2 | Existing D110 LCD driver |
| LCD D4..D7 | PA4..PA7 | Existing D110 LCD driver |
| Keypad rows | PA1..PA3 | Existing D110 keypad driver |
| Keypad columns | PD2, PD3, PD7 | Existing D110 keypad driver |
| Lamp 1..4 | PB3, PC2, PC7, PD6 | Existing board LEDs |
| Lamp 5 | PC0 | Proteus / external low-voltage output |
| Dimming lamp | PC1 | 100 Hz software PWM, 0..100% |
| Temperature sensor | PA0 / ADC0 | LM35-compatible output |
| AC indicator / driver | PC6 | Automatic temperature control |
| Servo signal | PD5 / OC1A | Existing D110 servo driver / board header |
| Buzzer | PB0 | Beeps during login lockout |
| UART RX / TX | PD0 / PD1 | Bluetooth or Proteus Virtual Terminal |

Timer1 remains assigned to the servo. Timer2 drives the dimmer PWM. The buzzer
uses a direct output during lockout and does not reconfigure Timer0.

## Proteus 8

`Proteus/SmartHome_Wiring.md` gives the component and pin connections for a
complete six-lamp simulation. This package contains firmware and a wiring guide;
it does not contain a Proteus `.pdsprj` schematic because Proteus is not
installed in the build environment used to prepare this package.

Set the ATmega32A clock to 16 MHz and load `out/D110/default.hex`. In Proteus,
connect all four board LED outputs plus PC0 and PC1 to six low-voltage lamp/LED
models. Use an LM35 model or a potentiometer on PA0 to vary the temperature.
Use a Virtual Terminal at 9600 baud for the Bluetooth command interface.

## Driver modules added

- `HAL/LIGHTS`: four board LEDs plus the fifth on/off lamp output.
- `HAL/DIMMER`: Timer2 software PWM output.
- `HAL/TEMP_SENSOR`: ADC0 / LM35 conversion.
- `HAL/AC_CONTROL`: 21/28 C hysteresis.
- `HAL/USER_STORE`: EEPROM users and local PIN.
- `HAL/ALARM`: lockout buzzer output.
