/**
 * @file BUZZER.h
 * @brief Interface for interrupt-driven, timed buzzer tones on Timer0.
 */
#ifndef BUZZER_H
#define BUZZER_H

#include <stdint.h>
#include "../../MCAL/DIO/DIO.h"


#define BUZZER_PIN GPIO_PB0


void BUZZER_init();

void BUZZER_on(uint16_t freq, uint16_t ms);

void BUZZER_off();

#endif 
