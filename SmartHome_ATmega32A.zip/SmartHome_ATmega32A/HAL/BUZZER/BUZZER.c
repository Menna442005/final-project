
#include "../../CONFIG.h"
#include "BUZZER.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include "../../MCAL/TIMER/TIMER.h"
#include "../../MCAL/DIO/DIO.h"



uint32_t BUZZER_delay_ticks = 0 ;
static void Buzzer_Toggle(void);


void BUZZER_init(){
    
    TIMER0_init(TIMER0_CTC_MODE, TIMER0_OCR0_DISCONNECTED,TIMER0_PRESCALER_64);
    GPIO_Pin_Mode(BUZZER_PIN,GPIO_DIO_OUTPUT);
    
    TIMER0_OCR0_interrupt_init(Buzzer_Toggle);
    TIMER0_OCR0_interrupt_EN();
}

void BUZZER_on(uint16_t freq, uint16_t ms){
    
    uint32_t ticks;

    BUZZER_delay_ticks = ((uint32_t)freq * ms * 2)  / 1000;
    
    if (freq == 0U) {
        BUZZER_off();
        return;
    }

 
    ticks = (F_CPU + (2UL * 64UL * freq) / 2UL) / (2UL * 64UL * freq);

   
    if (ticks < 1UL) {
        ticks = 1UL;
    } else if (ticks > 256UL) {
        ticks = 256UL;
    }

   
    TIMER0_setOCR0((uint8_t)(ticks - 1UL));
    TIMER0_OCR0_interrupt_EN();
}

void BUZZER_off(){
      TIMER0_OCR0_interrupt_disable();
      DIO_clear_pin(BUZZER_PIN);
}


static void Buzzer_Toggle(void)
{
   
    static uint32_t ticks = 0;
    ticks ++;
    DIO_toggle_pin(BUZZER_PIN);
    
    if(ticks >= BUZZER_delay_ticks){
        ticks = 0;
        BUZZER_delay_ticks = 0;
        BUZZER_off();
    }
}
