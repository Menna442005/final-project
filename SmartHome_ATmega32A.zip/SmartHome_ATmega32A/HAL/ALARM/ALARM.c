#include "ALARM.h"

#include "../../MCAL/DIO/DIO.h"
#include "../../MCAL/GPIO/GPIO.h"

#define ALARM_PIN GPIO_PB0

void ALARM_init(void)
{
    GPIO_Pin_Mode(ALARM_PIN, GPIO_DIO_OUTPUT);
    DIO_clear_pin(ALARM_PIN);
}

void ALARM_set(uint8_t enabled)
{
    if (enabled != 0U)
    {
        DIO_set_pin(ALARM_PIN);
    }
    else
    {
        DIO_clear_pin(ALARM_PIN);
    }
}
