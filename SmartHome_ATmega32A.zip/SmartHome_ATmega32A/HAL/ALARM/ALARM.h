
#ifndef ALARM_H
#define ALARM_H

#include <stdint.h>

void ALARM_init(void);
void ALARM_set(uint8_t enabled);

#endif
