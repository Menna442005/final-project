
#ifndef LIGHTS_H
#define LIGHTS_H

#include <stdint.h>

#define LIGHTS_COUNT 5U

void LIGHTS_init(void);
void LIGHTS_set(uint8_t lamp, uint8_t state);
void LIGHTS_toggle(uint8_t lamp);
uint8_t LIGHTS_get(uint8_t lamp);

#endif
