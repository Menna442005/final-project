#include "LIGHTS.h"

#include "../LEDS/LEDS.h"
#include "../../MCAL/DIO/DIO.h"
#include "../../MCAL/GPIO/GPIO.h"

#define LIGHT_5_PIN GPIO_PC0

static uint8_t light_state[LIGHTS_COUNT] = {0U, 0U, 0U, 0U, 0U};

void LIGHTS_init(void)
{
    LED_init();
    GPIO_Pin_Mode(LIGHT_5_PIN, GPIO_DIO_OUTPUT);
    DIO_clear_pin(LIGHT_5_PIN);

    LIGHTS_set(1U, 0U);
    LIGHTS_set(2U, 0U);
    LIGHTS_set(3U, 0U);
    LIGHTS_set(4U, 0U);
}

void LIGHTS_set(uint8_t lamp, uint8_t state)
{
    if (lamp < 1U || lamp > LIGHTS_COUNT)
    {
        return;
    }

    state = (state != 0U) ? 1U : 0U;
    light_state[lamp - 1U] = state;

    switch (lamp)
    {
        case 1U:
            state ? LED_On(LED1) : LED_Off(LED1);
            break;
        case 2U:
            state ? LED_On(LED2) : LED_Off(LED2);
            break;
        case 3U:
            state ? LED_On(LED3) : LED_Off(LED3);
            break;
        case 4U:
            state ? LED_On(LED4) : LED_Off(LED4);
            break;
        case 5U:
            state ? DIO_set_pin(LIGHT_5_PIN) : DIO_clear_pin(LIGHT_5_PIN);
            break;
        default:
            break;
    }
}

void LIGHTS_toggle(uint8_t lamp)
{
    if (lamp >= 1U && lamp <= LIGHTS_COUNT)
    {
        LIGHTS_set(lamp, (uint8_t)!light_state[lamp - 1U]);
    }
}

uint8_t LIGHTS_get(uint8_t lamp)
{
    if (lamp < 1U || lamp > LIGHTS_COUNT)
    {
        return 0U;
    }

    return light_state[lamp - 1U];
}
