
#ifndef TEMP_SENSOR_H
#define TEMP_SENSOR_H

#include <stdint.h>

void TEMP_SENSOR_init(void);
uint8_t TEMP_SENSOR_readCelsius(void);

#endif
