#include "TEMP_SENSOR.h"

#include <avr/io.h>

#include "../../MCAL/ADC/ADC.h"
#include "../../TOOLS.h"

void TEMP_SENSOR_init(void)
{
   
    CLEAR_BIT(DDRA, DDA0);
    CLEAR_BIT(PORTA, PA0);

    ADC_init(ADC_AVCC_REFRENCE,
             ADC_SINGLE_ENDED_ADC0,
             ADC_RESULT_RIGHT_ADJUST,
             ADC_PRESCALER_128,
             ADC_NO_AUTO_TRIGGER);
}

uint8_t TEMP_SENSOR_readCelsius(void)
{
    uint16_t adc_value;
    uint32_t temperature;

    ADC_start_conversion();
    adc_value = ADC_read_10bit();

    /* LM35: 10 mV/degree C; AVCC reference is nominally 5 V. */
    temperature = ((uint32_t)adc_value * 500UL + 512UL) / 1024UL;
    if (temperature > 255UL)
    {
        temperature = 255UL;
    }

    return (uint8_t)temperature;
}
