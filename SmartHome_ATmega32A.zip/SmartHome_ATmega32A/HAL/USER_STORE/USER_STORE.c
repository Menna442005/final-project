#include "USER_STORE.h"

#include <avr/eeprom.h>
#include <string.h>

#define USER_STORE_MAGIC 0xA7U
#define USER_STORE_DEFAULT_ADMIN "admin"
#define USER_STORE_DEFAULT_PASSWORD "1234"
#define USER_STORE_DEFAULT_LOCAL_PIN "4567"

typedef struct
{
    uint8_t active;
    uint8_t role;
    char username[USER_STORE_NAME_SIZE];
    char password[USER_STORE_PASSWORD_SIZE];
} USER_Record_t;

static uint8_t ee_magic EEMEM;
static USER_Record_t ee_users[USER_STORE_MAX_USERS] EEMEM;
static char ee_local_pin[USER_STORE_LOCAL_PIN_SIZE] EEMEM;

static uint8_t USER_STORE_equalIgnoreCase(const char *left, const char *right)
{
    while (*left != '\0' && *right != '\0')
    {
        char a = *left;
        char b = *right;
        if (a >= 'A' && a <= 'Z')
        {
            a = (char)(a - 'A' + 'a');
        }
        if (b >= 'A' && b <= 'Z')
        {
            b = (char)(b - 'A' + 'a');
        }
        if (a != b)
        {
            return 0U;
        }
        left++;
        right++;
    }
    return (uint8_t)(*left == '\0' && *right == '\0');
}

static uint8_t USER_STORE_validText(const char *text, uint8_t capacity)
{
    uint8_t length = 0U;
    if (text == 0 || text[0] == '\0' || capacity < 2U)
    {
        return 0U;
    }
    while (text[length] != '\0' && length < (uint8_t)(capacity - 1U))
    {
        length++;
    }
    return (uint8_t)(text[length] == '\0');
}

static void USER_STORE_readRecord(uint8_t index, USER_Record_t *record)
{
    eeprom_read_block(record, &ee_users[index], sizeof(USER_Record_t));
}

void USER_STORE_init(void)
{
    uint8_t i;
    USER_Record_t record;

    if (eeprom_read_byte(&ee_magic) == USER_STORE_MAGIC)
    {
        return;
    }

    memset(&record, 0, sizeof(record));
    record.active = 1U;
    record.role = USER_ROLE_ADMIN;
    strcpy(record.username, USER_STORE_DEFAULT_ADMIN);
    strcpy(record.password, USER_STORE_DEFAULT_PASSWORD);
    eeprom_update_block(&record, &ee_users[0], sizeof(record));

    memset(&record, 0, sizeof(record));
    for (i = 1U; i < USER_STORE_MAX_USERS; i++)
    {
        eeprom_update_block(&record, &ee_users[i], sizeof(record));
    }

    eeprom_update_block(USER_STORE_DEFAULT_LOCAL_PIN,
                        ee_local_pin,
                        sizeof(USER_STORE_DEFAULT_LOCAL_PIN));
    eeprom_update_byte(&ee_magic, USER_STORE_MAGIC);
}

USER_ROLE_t USER_STORE_authenticate(const char *username, const char *password)
{
    uint8_t i;
    USER_Record_t record;

    if (!USER_STORE_validText(username, USER_STORE_NAME_SIZE) ||
        !USER_STORE_validText(password, USER_STORE_PASSWORD_SIZE))
    {
        return USER_ROLE_NONE;
    }

    for (i = 0U; i < USER_STORE_MAX_USERS; i++)
    {
        USER_STORE_readRecord(i, &record);
        if (record.active && USER_STORE_equalIgnoreCase(username, record.username) &&
            strcmp(password, record.password) == 0)
        {
            return (USER_ROLE_t)record.role;
        }
    }
    return USER_ROLE_NONE;
}

uint8_t USER_STORE_addUser(const char *username, const char *password)
{
    uint8_t i;
    uint8_t free_index = USER_STORE_MAX_USERS;
    USER_Record_t record;

    if (!USER_STORE_validText(username, USER_STORE_NAME_SIZE) ||
        !USER_STORE_validText(password, USER_STORE_PASSWORD_SIZE) ||
        USER_STORE_equalIgnoreCase(username, USER_STORE_DEFAULT_ADMIN))
    {
        return 0U;
    }

    for (i = 0U; i < USER_STORE_MAX_USERS; i++)
    {
        USER_STORE_readRecord(i, &record);
        if (record.active && USER_STORE_equalIgnoreCase(username, record.username))
        {
            return 0U;
        }
        if (!record.active && free_index == USER_STORE_MAX_USERS)
        {
            free_index = i;
        }
    }

    if (free_index == USER_STORE_MAX_USERS)
    {
        return 0U;
    }

    memset(&record, 0, sizeof(record));
    record.active = 1U;
    record.role = USER_ROLE_USER;
    strcpy(record.username, username);
    strcpy(record.password, password);
    eeprom_update_block(&record, &ee_users[free_index], sizeof(record));
    return 1U;
}

uint8_t USER_STORE_deleteUser(const char *username)
{
    uint8_t i;
    USER_Record_t record;

    if (username == 0 || USER_STORE_equalIgnoreCase(username, USER_STORE_DEFAULT_ADMIN))
    {
        return 0U;
    }

    for (i = 1U; i < USER_STORE_MAX_USERS; i++)
    {
        USER_STORE_readRecord(i, &record);
        if (record.active && USER_STORE_equalIgnoreCase(username, record.username))
        {
            memset(&record, 0, sizeof(record));
            eeprom_update_block(&record, &ee_users[i], sizeof(record));
            return 1U;
        }
    }
    return 0U;
}

uint8_t USER_STORE_changePassword(const char *username, const char *password)
{
    uint8_t i;
    USER_Record_t record;

    if (!USER_STORE_validText(username, USER_STORE_NAME_SIZE) ||
        !USER_STORE_validText(password, USER_STORE_PASSWORD_SIZE))
    {
        return 0U;
    }

    for (i = 0U; i < USER_STORE_MAX_USERS; i++)
    {
        USER_STORE_readRecord(i, &record);
        if (record.active && USER_STORE_equalIgnoreCase(username, record.username))
        {
            memset(record.password, 0, sizeof(record.password));
            strcpy(record.password, password);
            eeprom_update_block(&record, &ee_users[i], sizeof(record));
            return 1U;
        }
    }
    return 0U;
}

uint8_t USER_STORE_checkLocalPin(const char *pin)
{
    char saved_pin[USER_STORE_LOCAL_PIN_SIZE];
    eeprom_read_block(saved_pin, ee_local_pin, sizeof(saved_pin));
    saved_pin[USER_STORE_LOCAL_PIN_SIZE - 1U] = '\0';
    return (uint8_t)(pin != 0 && strcmp(pin, saved_pin) == 0);
}

uint8_t USER_STORE_getUsername(uint8_t index, char *username, uint8_t capacity)
{
    USER_Record_t record;
    uint8_t i;

    if (index >= USER_STORE_MAX_USERS || username == 0 || capacity == 0U)
    {
        return 0U;
    }
    USER_STORE_readRecord(index, &record);
    if (!record.active)
    {
        return 0U;
    }
    for (i = 0U; i < capacity - 1U && i < USER_STORE_NAME_SIZE - 1U; i++)
    {
        username[i] = record.username[i];
        if (record.username[i] == '\0')
        {
            return 1U;
        }
    }
    username[i] = '\0';
    return 1U;
}
