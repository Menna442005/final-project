
#ifndef USER_STORE_H
#define USER_STORE_H

#include <stdint.h>

#define USER_STORE_MAX_USERS 8U
#define USER_STORE_NAME_SIZE 12U
#define USER_STORE_PASSWORD_SIZE 12U
#define USER_STORE_LOCAL_PIN_SIZE 5U

typedef enum
{
    USER_ROLE_NONE = 0U,
    USER_ROLE_USER = 1U,
    USER_ROLE_ADMIN = 2U
} USER_ROLE_t;

void USER_STORE_init(void);
USER_ROLE_t USER_STORE_authenticate(const char *username, const char *password);
uint8_t USER_STORE_addUser(const char *username, const char *password);
uint8_t USER_STORE_deleteUser(const char *username);
uint8_t USER_STORE_changePassword(const char *username, const char *password);
uint8_t USER_STORE_checkLocalPin(const char *pin);
uint8_t USER_STORE_getUsername(uint8_t index, char *username, uint8_t capacity);

#endif
