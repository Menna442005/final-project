
#ifndef DIMMER_H
#define DIMMER_H

#include <stdint.h>

void DIMMER_init(void);
void DIMMER_setLevel(uint8_t percent);
uint8_t DIMMER_getLevel(void);

#endif
