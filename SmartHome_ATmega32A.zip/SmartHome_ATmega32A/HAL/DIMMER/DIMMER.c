#include "DIMMER.h"

#include <avr/interrupt.h>
#include <avr/io.h>

#include "../../MCAL/GPIO/GPIO.h"

#define DIMMER_PIN GPIO_PC1
#define DIMMER_PWM_STEPS 100U

static volatile uint8_t dimmer_level = 0U;
static volatile uint8_t dimmer_phase = 0U;

ISR(TIMER2_COMP_vect)
{
    dimmer_phase++;
    if (dimmer_phase >= DIMMER_PWM_STEPS)
    {
        dimmer_phase = 0U;
    }

    if (dimmer_phase < dimmer_level)
    {
        PORTC |= (1U << PC1);
    }
    else
    {
        PORTC &= (uint8_t)~(1U << PC1);
    }
}

void DIMMER_init(void)
{
    GPIO_Pin_Mode(DIMMER_PIN, GPIO_DIO_OUTPUT);
    PORTC &= (uint8_t)~(1U << PC1);

    /* 16 MHz / 8 / (199 + 1) = 10 kHz interrupt; 100 steps give 100 Hz PWM. */
    TCCR2 = 0U;
    TCNT2 = 0U;
    OCR2 = 199U;
    TIFR = (1U << OCF2);
    TIMSK |= (1U << OCIE2);
    TCCR2 = (1U << WGM21) | (1U << CS21);
}

void DIMMER_setLevel(uint8_t percent)
{
    if (percent > 100U)
    {
        percent = 100U;
    }
    dimmer_level = percent;
}

uint8_t DIMMER_getLevel(void)
{
    return dimmer_level;
}
