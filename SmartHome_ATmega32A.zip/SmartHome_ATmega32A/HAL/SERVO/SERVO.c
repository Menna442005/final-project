#include "SERVO.h"
#include "../../MCAL/TIMER/TIMER.h"
#include "../../MCAL/DIO/DIO.h"
#include <stdint.h>

void SERVO_init(){
    GPIO_Pin_Mode(GPIO_PD5,GPIO_DIO_OUTPUT);
    TIMER1_init(TIMER1_FAST_PWM_ICR1,
                TIMER1_OCR1A_FAST_PWM_NON_INVERTING,
                TIMER1_OCR1B_DISCONNECTED,
                TIMER1_PRESCALER_64);
    TIMER1_setICR1(4999);
}
void SERVO_Set_angle(uint8_t angle){
    if (angle > 180) {
        angle = 180;
    }
    TIMER1_setOCR1A((uint16_t)MAP(angle, 0, 180, 125, 625));
}
uint8_t SERVO_Get_angle(){
    uint16_t pulse = OCR1A;
    /* Report the commanded angle, bounded to the configured servo range. */
    if (pulse <= 125) {
        return 0;
    }
    if (pulse >= 625) {
        return 180;
    }
    return (uint8_t)MAP(pulse, 125, 625, 0, 180);
}
