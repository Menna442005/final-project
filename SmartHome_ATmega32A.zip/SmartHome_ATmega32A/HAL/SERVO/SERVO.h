#ifndef  SERVO_H
#define SERVO_H
#include <stdint.h>

void SERVO_init();
void SERVO_Set_angle(uint8_t angle);
uint8_t SERVO_Get_angle();




#endif  