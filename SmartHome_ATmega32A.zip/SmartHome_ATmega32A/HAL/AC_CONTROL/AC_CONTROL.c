#include "AC_CONTROL.h"

#include "../../MCAL/DIO/DIO.h"
#include "../../MCAL/GPIO/GPIO.h"

#define AC_OUTPUT_PIN GPIO_PC6
#define AC_ON_TEMPERATURE 28U
#define AC_OFF_TEMPERATURE 21U

static uint8_t ac_is_on = 0U;

void AC_CONTROL_init(void)
{
    GPIO_Pin_Mode(AC_OUTPUT_PIN, GPIO_DIO_OUTPUT);
    DIO_clear_pin(AC_OUTPUT_PIN);
    ac_is_on = 0U;
}

void AC_CONTROL_update(uint8_t temperature_celsius)
{
    if (temperature_celsius > AC_ON_TEMPERATURE)
    {
        ac_is_on = 1U;
        DIO_set_pin(AC_OUTPUT_PIN);
    }
    else if (temperature_celsius < AC_OFF_TEMPERATURE)
    {
        ac_is_on = 0U;
        DIO_clear_pin(AC_OUTPUT_PIN);
    }
}

uint8_t AC_CONTROL_isOn(void)
{
    return ac_is_on;
}
