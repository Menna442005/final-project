
#ifndef AC_CONTROL_H
#define AC_CONTROL_H

#include <stdint.h>

void AC_CONTROL_init(void);
void AC_CONTROL_update(uint8_t temperature_celsius);
uint8_t AC_CONTROL_isOn(void);

#endif
