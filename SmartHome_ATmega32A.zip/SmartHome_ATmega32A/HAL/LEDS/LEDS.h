
#ifndef LEDS_H
#define LEDS_H

#include "../../MCAL/DIO/DIO.h"
#include "../../MCAL/GPIO/GPIO.h"



typedef enum {
    LED1 = GPIO_PB3,
    LED2 = GPIO_PC2,
    LED3 = GPIO_PC7,
    LED4 = GPIO_PD6
}LEDS_t;

void LED_Toggle (LEDS_t led);

void LED_Off (LEDS_t led);

void LED_On (LEDS_t led);

void LED_init ();

#endif 
