
#include "LEDS.h"


void LED_init (){
  
    GPIO_Pin_Mode (LED1,GPIO_DIO_OUTPUT );
    GPIO_Pin_Mode (LED2,GPIO_DIO_OUTPUT );
    GPIO_Pin_Mode (LED3,GPIO_DIO_OUTPUT );
    GPIO_Pin_Mode (LED4,GPIO_DIO_OUTPUT );
}

void LED_On (LEDS_t led){
    DIO_set_pin(led);
}

void LED_Off (LEDS_t led){
    DIO_clear_pin(led);
}

void LED_Toggle (LEDS_t led){
    DIO_toggle_pin(led);
}

