
#ifndef KEYPAD_H
#define KEYPAD_H

#include "../../MCAL/GPIO/GPIO.h"



#ifdef KEYPAD_DIRECT_MODE


#define KEYPAD_BUTTON_1_DDR            DDRD
#define KEYPAD_BUTTON_1_PORT           PORTD
#define KEYPAD_BUTTON_1_PIN            PIND
#define KEYPAD_BUTTON_1_PIN_NO         PIN2

#define KEYPAD_BUTTON_2_DDR            DDRD
#define KEYPAD_BUTTON_2_PORT           PORTD
#define KEYPAD_BUTTON_2_PIN            PIND
#define KEYPAD_BUTTON_2_PIN_NO         PIN3

#define KEYPAD_BUTTON_3_DDR            DDRD
#define KEYPAD_BUTTON_3_PORT           PORTD
#define KEYPAD_BUTTON_3_PIN            PIND
#define KEYPAD_BUTTON_3_PIN_NO         PIN7


#else


#define KEYPAD_ROW_1_DDR               DDRA
#define KEYPAD_ROW_1_PORT              PORTA
#define KEYPAD_ROW_1_PIN               PINA
#define KEYPAD_ROW_1_PIN_NO            PIN1

#define KEYPAD_ROW_2_DDR               DDRA
#define KEYPAD_ROW_2_PORT              PORTA
#define KEYPAD_ROW_2_PIN               PINA
#define KEYPAD_ROW_2_PIN_NO            PIN2

#define KEYPAD_ROW_3_DDR               DDRA
#define KEYPAD_ROW_3_PORT              PORTA
#define KEYPAD_ROW_3_PIN               PINA
#define KEYPAD_ROW_3_PIN_NO            PIN3

#define KEYPAD_COL_1_DDR               DDRD
#define KEYPAD_COL_1_PORT              PORTD
#define KEYPAD_COL_1_PIN               PIND
#define KEYPAD_COL_1_PIN_NO            PIN2

#define KEYPAD_COL_2_DDR               DDRD
#define KEYPAD_COL_2_PORT              PORTD
#define KEYPAD_COL_2_PIN               PIND
#define KEYPAD_COL_2_PIN_NO            PIN3

#define KEYPAD_COL_3_DDR               DDRD
#define KEYPAD_COL_3_PORT              PORTD
#define KEYPAD_COL_3_PIN               PIND
#define KEYPAD_COL_3_PIN_NO            PIN7


#endif


#define KEYPAD_DEBOUNCE_COUNT          5

#define KEYPAD_RELEASED                GPIO_HIGH

#define KEYPAD_PRESSED                 GPIO_LOW


typedef enum {
    KEYPAD_NO_KEY, 
    KEYPAD_SW1 = 1,
    KEYPAD_SW2,
    KEYPAD_SW3,
    KEYPAD_SW4,
    KEYPAD_SW5,
    KEYPAD_SW6,
    KEYPAD_SW7,
    KEYPAD_SW8,
    KEYPAD_SW9
} KEYPAD_switch_t;


typedef enum {
    KEYPAD_INTERNAL_PULLUP,
    KEYPAD_EXTERNAL_PULLUP
} KEYPAD_Pull_t;


void KEYPAD_init(KEYPAD_Pull_t pullup);

KEYPAD_switch_t KEYPAD_getKey(void);

#endif 
