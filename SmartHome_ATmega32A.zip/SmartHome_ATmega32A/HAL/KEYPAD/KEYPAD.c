
#include "KEYPAD.h"



typedef struct {

    uint8_t last_read;


    uint8_t stable_state;


    uint8_t debounce_count;
} KEYPAD_ButtonState_t;


static KEYPAD_switch_t KEYPAD_checkButtonState(
    uint8_t current_state,
    KEYPAD_ButtonState_t *button,
    KEYPAD_switch_t key
);

#ifdef KEYPAD_DIRECT_MODE

static KEYPAD_switch_t KEYPAD_checkButton(
    volatile uint8_t *pin_reg,
    GPIO_PIN_t pin_no,
    KEYPAD_ButtonState_t *button,
    KEYPAD_switch_t key
);
#else

static KEYPAD_switch_t KEYPAD_checkRows(
    volatile uint8_t *col,
    GPIO_PIN_t pin_no,
    KEYPAD_switch_t SW_row1,
    KEYPAD_switch_t SW_row2,
    KEYPAD_switch_t SW_row3,
    KEYPAD_ButtonState_t keyState[3]
);


static void KEYPAD_releaseRows(
    KEYPAD_ButtonState_t keyState[3],
    KEYPAD_switch_t SW_row1,
    KEYPAD_switch_t SW_row2,
    KEYPAD_switch_t SW_row3
);
#endif

/** @copydoc KEYPAD_init */
void KEYPAD_init(KEYPAD_Pull_t pullup)
{
#ifdef KEYPAD_DIRECT_MODE

    GPIO_Pin_Direction(&KEYPAD_BUTTON_1_DDR, KEYPAD_BUTTON_1_PIN_NO, GPIO_INPUT);
    GPIO_Pin_Direction(&KEYPAD_BUTTON_2_DDR, KEYPAD_BUTTON_2_PIN_NO, GPIO_INPUT);
    GPIO_Pin_Direction(&KEYPAD_BUTTON_3_DDR, KEYPAD_BUTTON_3_PIN_NO, GPIO_INPUT);

    if(pullup == KEYPAD_INTERNAL_PULLUP) {
        GPIO_Set_PullUp(&KEYPAD_BUTTON_1_PORT, KEYPAD_BUTTON_1_PIN_NO);
        GPIO_Set_PullUp(&KEYPAD_BUTTON_2_PORT, KEYPAD_BUTTON_2_PIN_NO);
        GPIO_Set_PullUp(&KEYPAD_BUTTON_3_PORT, KEYPAD_BUTTON_3_PIN_NO);
    }
#else

    GPIO_Pin_Direction(&KEYPAD_ROW_1_DDR, KEYPAD_ROW_1_PIN_NO, GPIO_OUTPUT);
    GPIO_Pin_Direction(&KEYPAD_ROW_2_DDR, KEYPAD_ROW_2_PIN_NO, GPIO_OUTPUT);
    GPIO_Pin_Direction(&KEYPAD_ROW_3_DDR, KEYPAD_ROW_3_PIN_NO, GPIO_OUTPUT);

    GPIO_Pin_Write(&KEYPAD_ROW_1_PORT, KEYPAD_ROW_1_PIN_NO, GPIO_LOW);
    GPIO_Pin_Write(&KEYPAD_ROW_2_PORT, KEYPAD_ROW_2_PIN_NO, GPIO_LOW);
    GPIO_Pin_Write(&KEYPAD_ROW_3_PORT, KEYPAD_ROW_3_PIN_NO, GPIO_LOW);

    GPIO_Pin_Direction(&KEYPAD_COL_1_DDR, KEYPAD_COL_1_PIN_NO, GPIO_INPUT);
    GPIO_Pin_Direction(&KEYPAD_COL_2_DDR, KEYPAD_COL_2_PIN_NO, GPIO_INPUT);
    GPIO_Pin_Direction(&KEYPAD_COL_3_DDR, KEYPAD_COL_3_PIN_NO, GPIO_INPUT);

    if(pullup == KEYPAD_INTERNAL_PULLUP) {
        GPIO_Set_PullUp(&KEYPAD_COL_1_PORT, KEYPAD_COL_1_PIN_NO);
        GPIO_Set_PullUp(&KEYPAD_COL_2_PORT, KEYPAD_COL_2_PIN_NO);
        GPIO_Set_PullUp(&KEYPAD_COL_3_PORT, KEYPAD_COL_3_PIN_NO);
    }
#endif
}


KEYPAD_switch_t KEYPAD_getKey(void)
{
#ifdef KEYPAD_DIRECT_MODE

    static KEYPAD_ButtonState_t button1_state = {KEYPAD_RELEASED, KEYPAD_RELEASED, 0};
    static KEYPAD_ButtonState_t button2_state = {KEYPAD_RELEASED, KEYPAD_RELEASED, 0};
    static KEYPAD_ButtonState_t button3_state = {KEYPAD_RELEASED, KEYPAD_RELEASED, 0};

    KEYPAD_switch_t key;

    key = KEYPAD_checkButton(
        &KEYPAD_BUTTON_1_PIN,
        KEYPAD_BUTTON_1_PIN_NO,
        &button1_state,
        KEYPAD_SW1
    );
    if(key != KEYPAD_NO_KEY) {
        return key;
    }

    key = KEYPAD_checkButton(
        &KEYPAD_BUTTON_2_PIN,
        KEYPAD_BUTTON_2_PIN_NO,
        &button2_state,
        KEYPAD_SW2
    );
    if(key != KEYPAD_NO_KEY) {
        return key;
    }

    key = KEYPAD_checkButton(
        &KEYPAD_BUTTON_3_PIN,
        KEYPAD_BUTTON_3_PIN_NO,
        &button3_state,
        KEYPAD_SW3
    );
    if(key != KEYPAD_NO_KEY) {
        return key;
    }

    return KEYPAD_NO_KEY;
#else

    static KEYPAD_ButtonState_t key_state[3][3] = {
        {
            {KEYPAD_RELEASED, KEYPAD_RELEASED, 0},
            {KEYPAD_RELEASED, KEYPAD_RELEASED, 0},
            {KEYPAD_RELEASED, KEYPAD_RELEASED, 0}
        },
        {
            {KEYPAD_RELEASED, KEYPAD_RELEASED, 0},
            {KEYPAD_RELEASED, KEYPAD_RELEASED, 0},
            {KEYPAD_RELEASED, KEYPAD_RELEASED, 0}
        },
        {
            {KEYPAD_RELEASED, KEYPAD_RELEASED, 0},
            {KEYPAD_RELEASED, KEYPAD_RELEASED, 0},
            {KEYPAD_RELEASED, KEYPAD_RELEASED, 0}
        }
    };

    /*
     * First stage of matrix scan:
     * Check which column is pulled LOW while all rows are LOW.
     *
     * If column 1 is LOW, one of SW1/SW4/SW7 is pressed.
     * If column 2 is LOW, one of SW2/SW5/SW8 is pressed.
     * If column 3 is LOW, one of SW3/SW6/SW9 is pressed.
     *
     * After finding the active column, KEYPAD_checkRows() drives rows HIGH one
     * by one to discover which row is connected through the pressed key.
     */
    if(GPIO_Pin_Read(&KEYPAD_COL_1_PIN, KEYPAD_COL_1_PIN_NO) == GPIO_LOW) {
        return KEYPAD_checkRows(
            &KEYPAD_COL_1_PIN,
            KEYPAD_COL_1_PIN_NO,
            KEYPAD_SW1,
            KEYPAD_SW4,
            KEYPAD_SW7,
            key_state[0]
        );
    } else if(GPIO_Pin_Read(&KEYPAD_COL_2_PIN, KEYPAD_COL_2_PIN_NO) == GPIO_LOW) {
        return KEYPAD_checkRows(
            &KEYPAD_COL_2_PIN,
            KEYPAD_COL_2_PIN_NO,
            KEYPAD_SW2,
            KEYPAD_SW5,
            KEYPAD_SW8,
            key_state[1]
        );
    } else if(GPIO_Pin_Read(&KEYPAD_COL_3_PIN, KEYPAD_COL_3_PIN_NO) == GPIO_LOW) {
        return KEYPAD_checkRows(
            &KEYPAD_COL_3_PIN,
            KEYPAD_COL_3_PIN_NO,
            KEYPAD_SW3,
            KEYPAD_SW6,
            KEYPAD_SW9,
            key_state[2]
        );
    } else {
        /*
         * No column is active, so no key is currently pressed.
         *
         * We still must feed RELEASED into every key's debounce state. Without
         * this, a key could remain stored as "pressed" forever and the next
         * press of the same key would not generate a new event.
         */
        KEYPAD_releaseRows(key_state[0], KEYPAD_SW1, KEYPAD_SW4, KEYPAD_SW7);
        KEYPAD_releaseRows(key_state[1], KEYPAD_SW2, KEYPAD_SW5, KEYPAD_SW8);
        KEYPAD_releaseRows(key_state[2], KEYPAD_SW3, KEYPAD_SW6, KEYPAD_SW9);

        return KEYPAD_NO_KEY;
    }
#endif
}

#ifndef KEYPAD_DIRECT_MODE

static KEYPAD_switch_t KEYPAD_checkRows(
    volatile uint8_t *col,
    GPIO_PIN_t pin_no,
    KEYPAD_switch_t SW_row1,
    KEYPAD_switch_t SW_row2,
    KEYPAD_switch_t SW_row3,
    KEYPAD_ButtonState_t keyState[3]
)
{


    GPIO_Pin_Write(&KEYPAD_ROW_1_PORT, KEYPAD_ROW_1_PIN_NO, GPIO_HIGH);
    if(GPIO_Pin_Read(col, pin_no) == GPIO_HIGH) {
        GPIO_Pin_Write(&KEYPAD_ROW_1_PORT, KEYPAD_ROW_1_PIN_NO, GPIO_LOW);
        return KEYPAD_checkButtonState(KEYPAD_PRESSED, &keyState[0], SW_row1);
    }
    GPIO_Pin_Write(&KEYPAD_ROW_1_PORT, KEYPAD_ROW_1_PIN_NO, GPIO_LOW);
    KEYPAD_checkButtonState(KEYPAD_RELEASED, &keyState[0], SW_row1);

    GPIO_Pin_Write(&KEYPAD_ROW_2_PORT, KEYPAD_ROW_2_PIN_NO, GPIO_HIGH);
    if(GPIO_Pin_Read(col, pin_no) == GPIO_HIGH) {
        GPIO_Pin_Write(&KEYPAD_ROW_2_PORT, KEYPAD_ROW_2_PIN_NO, GPIO_LOW);
        return KEYPAD_checkButtonState(KEYPAD_PRESSED, &keyState[1], SW_row2);
    }
    GPIO_Pin_Write(&KEYPAD_ROW_2_PORT, KEYPAD_ROW_2_PIN_NO, GPIO_LOW);
    KEYPAD_checkButtonState(KEYPAD_RELEASED, &keyState[1], SW_row2);

    GPIO_Pin_Write(&KEYPAD_ROW_3_PORT, KEYPAD_ROW_3_PIN_NO, GPIO_HIGH);
    if(GPIO_Pin_Read(col, pin_no) == GPIO_HIGH) {
        GPIO_Pin_Write(&KEYPAD_ROW_3_PORT, KEYPAD_ROW_3_PIN_NO, GPIO_LOW);
        return KEYPAD_checkButtonState(KEYPAD_PRESSED, &keyState[2], SW_row3);
    }
    GPIO_Pin_Write(&KEYPAD_ROW_3_PORT, KEYPAD_ROW_3_PIN_NO, GPIO_LOW);
    KEYPAD_checkButtonState(KEYPAD_RELEASED, &keyState[2], SW_row3);

    return KEYPAD_NO_KEY;
}
#endif

#ifdef KEYPAD_DIRECT_MODE

static KEYPAD_switch_t KEYPAD_checkButton(
    volatile uint8_t *pin_reg,
    GPIO_PIN_t pin_no,
    KEYPAD_ButtonState_t *button,
    KEYPAD_switch_t key
)
{

    return KEYPAD_checkButtonState(GPIO_Pin_Read(pin_reg, pin_no), button, key);
}
#endif

static KEYPAD_switch_t KEYPAD_checkButtonState(
    uint8_t current_state,
    KEYPAD_ButtonState_t *button,
    KEYPAD_switch_t key
)
{

    if(current_state != button->last_read) {
        button->last_read = current_state;
        button->debounce_count = 0;
        return KEYPAD_NO_KEY;
    }


    if(button->debounce_count < KEYPAD_DEBOUNCE_COUNT) {
        button->debounce_count++;
        return KEYPAD_NO_KEY;
    }


    if(current_state == button->stable_state) {
        return KEYPAD_NO_KEY;
    }


    button->stable_state = current_state;

    if(current_state == KEYPAD_PRESSED) {
        return key;
    }

    return KEYPAD_NO_KEY;
}

#ifndef KEYPAD_DIRECT_MODE

static void KEYPAD_releaseRows(
    KEYPAD_ButtonState_t keyState[3],
    KEYPAD_switch_t SW_row1,
    KEYPAD_switch_t SW_row2,
    KEYPAD_switch_t SW_row3
)
{

    KEYPAD_checkButtonState(KEYPAD_RELEASED, &keyState[0], SW_row1);
    KEYPAD_checkButtonState(KEYPAD_RELEASED, &keyState[1], SW_row2);
    KEYPAD_checkButtonState(KEYPAD_RELEASED, &keyState[2], SW_row3);
}
#endif
