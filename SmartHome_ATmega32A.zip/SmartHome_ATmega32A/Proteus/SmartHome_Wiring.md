# Proteus 8 wiring guide

This sheet is for building the simulation around the compiled firmware at
`out/D110/default.hex`. Set the ATmega32A clock to 16 MHz.

## ATmega32A connections

| MCU pin | Proteus component | Connection |
|---|---|---|
| VCC, AVCC | +5 V | Power both digital and analog supplies |
| GND pins | GND | Common ground |
| RESET | +5 V through 10 kOhm | Keep reset inactive |
| PA4..PA7 | LCD D4..D7 | Four-bit LCD data bus |
| PB1 | LCD RS | Register select |
| PB2 | LCD E | Enable |
| LCD R/W | GND | Write-only operation |
| PA1..PA3 | Keypad rows 1..3 | Three row wires |
| PD2, PD3, PD7 | Keypad columns 1..3 | Three column wires; add pull-ups if the keypad model needs them |
| PB3, PC2, PC7, PD6 | Lamps 1..4 | LED plus current-limiting resistor for each |
| PC0 | Lamp 5 | LED plus current-limiting resistor |
| PC1 | Dimming lamp | LED/load model through a suitable driver; PWM is 100 Hz |
| PA0 / ADC0 | LM35 output or potentiometer wiper | Vary from 0 to about 0.5 V to represent 0..50 C with an LM35 scale |
| PC6 | AC output | LED indicator or transistor-driver input |
| PD5 / OC1A | Servo signal | Servo signal input; servo supply and MCU share ground |
| PB0 | Buzzer | Active buzzer model |
| PD0 / RXD | Virtual Terminal TXD | Terminal-to-MCU data |
| PD1 / TXD | Virtual Terminal RXD | MCU-to-terminal data |

The UART terminal format is 9600 baud, 8 data bits, no parity, 1 stop bit.
Terminate each command with CR or LF. Use the same command list in the project
README. The simulation keypad should be wired as a 3x3 matrix using the listed
row and column pins.

## Expected lamp and temperature behavior

- Lamp outputs 1..4 and PC0 are on/off outputs.
- PC1 carries software PWM. `DIM 0`, `DIM 50`, and `DIM 100` should produce off,
  half brightness, and full brightness respectively in the chosen low-voltage
  lamp model.
- The AC output PC6 switches on when temperature rises above 28 C and switches
  off when temperature falls below 21 C. It holds its state in between.
- The door servo moves to 90 degrees for `DOOR OPEN` and 0 degrees for
  `DOOR CLOSE`; only an authenticated admin may issue those commands.

## Power and load note

Do not drive a motor or a high-power lamp directly from an ATmega32A output.
For Proteus, use LEDs or driver-stage models. For the physical kit, use only
low-voltage loads and the kit's supported output stages.
