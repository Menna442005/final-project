#include "CONFIG.h"

#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdint.h>
#include <string.h>
#include <util/delay.h>

#include "HAL/AC_CONTROL/AC_CONTROL.h"
#include "HAL/ALARM/ALARM.h"
#include "HAL/BT/BT.h"
#include "HAL/DIMMER/DIMMER.h"
#include "HAL/KEYPAD/KEYPAD.h"
#include "HAL/LCD/LCD.h"
#include "HAL/LIGHTS/LIGHTS.h"
#include "HAL/SERVO/SERVO.h"
#include "HAL/TEMP_SENSOR/TEMP_SENSOR.h"
#include "HAL/USER_STORE/USER_STORE.h"

#define SMART_HOME_LINE_CAPACITY       64U
#define SMART_HOME_TOKEN_COUNT         4U
#define SMART_HOME_MAX_FAILED_LOGINS   4U
#define SMART_HOME_LOCAL_PIN_LENGTH    4U
#define SMART_HOME_LOOP_DELAY_MS       5U
#define SMART_HOME_SENSOR_PERIOD_MS    250U
#define SMART_HOME_STATUS_PERIOD_MS    1000U
#define SMART_HOME_LOCAL_TIMEOUT_MS    60000U
#define SMART_HOME_DOOR_OPEN_ANGLE     90U
#define SMART_HOME_DOOR_CLOSED_ANGLE   0U

static USER_ROLE_t remote_role = USER_ROLE_NONE;
static char remote_username[USER_STORE_NAME_SIZE];
static uint8_t failed_login_count = 0U;
static uint8_t local_user_active = 0U;
static uint8_t admin_allows_local = 0U;
static char local_pin_input[SMART_HOME_LOCAL_PIN_LENGTH + 1U];
static uint8_t local_pin_length = 0U;
static uint8_t current_temperature = 0U;
static uint8_t local_dimmer_step = 0U;

static void send_text(const char *text)
{
    while (*text != '\0')
    {
        if (BT_writeByte((uint8_t)*text) != 0U)
        {
            text++;
        }
    }
}

static void send_line(const char *text)
{
    send_text(text);
    send_text("\r\n");
}

static void send_number(uint8_t value)
{
    char digits[4];
    uint8_t count = 0U;

    if (value >= 100U)
    {
        digits[count++] = (char)('0' + (value / 100U));
        value = (uint8_t)(value % 100U);
    }
    if (count > 0U || value >= 10U)
    {
        digits[count++] = (char)('0' + (value / 10U));
        value = (uint8_t)(value % 10U);
    }
    digits[count++] = (char)('0' + value);
    digits[count] = '\0';
    send_text(digits);
}

static void lcd_write_number(uint8_t value)
{
    if (value >= 100U)
    {
        LCD_Send_Data((uint8_t)('0' + (value / 100U)));
        value = (uint8_t)(value % 100U);
        LCD_Send_Data((uint8_t)('0' + (value / 10U)));
        value = (uint8_t)(value % 10U);
    }
    else if (value >= 10U)
    {
        LCD_Send_Data((uint8_t)('0' + (value / 10U)));
        value = (uint8_t)(value % 10U);
    }
    LCD_Send_Data((uint8_t)('0' + value));
}

static void display_status(void)
{
    uint8_t lamp;

    LCD_SendCommand(LCD_CLEAR_DISPLAY);
    LCD_Send_Str("T:");
    lcd_write_number(current_temperature);
    LCD_Send_Data('C');
    LCD_Send_Str(" AC:");
    LCD_Send_Str(AC_CONTROL_isOn() ? "ON" : "OFF");

    LCD_SendCommand(LCD_LINE2);
    LCD_Send_Str("L:");
    for (lamp = 1U; lamp <= LIGHTS_COUNT; lamp++)
    {
        LCD_Send_Data(LIGHTS_get(lamp) ? '1' : '0');
    }
    LCD_Send_Str(" D:");
    lcd_write_number(DIMMER_getLevel());
    LCD_Send_Data('%');
}

static void display_local_pin(void)
{
    uint8_t i;

    LCD_SendCommand(LCD_CLEAR_DISPLAY);
    LCD_Send_Str("Local user PIN");
    LCD_SendCommand(LCD_LINE2);
    for (i = 0U; i < local_pin_length; i++)
    {
        LCD_Send_Data('*');
    }
}

static void display_message(const char *line1, const char *line2)
{
    LCD_SendCommand(LCD_CLEAR_DISPLAY);
    LCD_Send_Str((char *)line1);
    LCD_SendCommand(LCD_LINE2);
    LCD_Send_Str((char *)line2);
}

static uint8_t read_bt_line(char *line, uint8_t capacity)
{
    static uint8_t line_length = 0U;
    static uint8_t overflow = 0U;
    uint8_t received;

    while (BT_readByte(&received) != 0U)
    {
        if (received == '\r' || received == '\n')
        {
            if (overflow != 0U)
            {
                line_length = 0U;
                overflow = 0U;
                return 2U;
            }
            if (line_length == 0U)
            {
                continue;
            }
            line[line_length] = '\0';
            line_length = 0U;
            return 1U;
        }

        if (overflow != 0U)
        {
            continue;
        }
        if (capacity > 1U && line_length < (uint8_t)(capacity - 1U))
        {
            line[line_length++] = (char)received;
        }
        else
        {
            overflow = 1U;
        }
    }
    return 0U;
}

static uint8_t split_tokens(char *line, char *tokens[], uint8_t capacity)
{
    uint8_t count = 0U;
    char *cursor = line;

    while (*cursor != '\0' && count < capacity)
    {
        while (*cursor == ' ' || *cursor == '\t')
        {
            cursor++;
        }
        if (*cursor == '\0')
        {
            break;
        }
        tokens[count++] = cursor;
        while (*cursor != '\0' && *cursor != ' ' && *cursor != '\t')
        {
            cursor++;
        }
        if (*cursor != '\0')
        {
            *cursor++ = '\0';
        }
    }
    return count;
}

static void uppercase_ascii(char *text)
{
    while (*text != '\0')
    {
        if (*text >= 'a' && *text <= 'z')
        {
            *text = (char)(*text - 'a' + 'A');
        }
        text++;
    }
}

static uint8_t parse_number(const char *text, uint8_t *value)
{
    uint16_t number = 0U;

    if (text == 0 || *text == '\0')
    {
        return 0U;
    }
    while (*text != '\0')
    {
        if (*text < '0' || *text > '9')
        {
            return 0U;
        }
        number = (uint16_t)(number * 10U + (uint8_t)(*text - '0'));
        if (number > 255U)
        {
            return 0U;
        }
        text++;
    }
    *value = (uint8_t)number;
    return 1U;
}

static void print_help(void)
{
    send_line("Commands:");
    send_line("LOGIN <name> <password>");
    send_line("ADD <name> <password> (admin)");
    send_line("DEL <name> (admin), LIST (admin)");
    send_line("LIGHT <1-5> <ON|OFF>");
    send_line("DIM <0-100>, DOOR <OPEN|CLOSE> (admin)");
    send_line("LOCAL <ENABLE|DISABLE> (admin)");
    send_line("PASS <new-password>, STATUS, LOGOUT");
}

static void enter_lockout(void)
{
    uint8_t alarm_state = 0U;

    display_message("SYSTEM LOCKED", "RESET REQUIRED");
    send_line("LOCKED: reset the MCU to continue.");

    while (1)
    {
        alarm_state = (uint8_t)!alarm_state;
        ALARM_set(alarm_state);
        _delay_ms(250);
    }
}

static void failed_login(void)
{
    failed_login_count++;
    if (failed_login_count >= SMART_HOME_MAX_FAILED_LOGINS)
    {
        enter_lockout();
    }
    send_line("Login failed.");
    send_text("Attempts remaining: ");
    send_number((uint8_t)(SMART_HOME_MAX_FAILED_LOGINS - failed_login_count));
    send_line("");
}

static uint8_t require_remote_login(void)
{
    if (remote_role == USER_ROLE_NONE)
    {
        send_line("Login first: LOGIN <name> <password>");
        return 0U;
    }
    return 1U;
}

static uint8_t require_admin(void)
{
    if (remote_role != USER_ROLE_ADMIN)
    {
        send_line("Admin permission required.");
        return 0U;
    }
    return 1U;
}

static void send_status(void)
{
    uint8_t lamp;

    send_text("Temperature: ");
    send_number(current_temperature);
    send_line(" C");
    send_text("AC: ");
    send_line(AC_CONTROL_isOn() ? "ON (automatic)" : "OFF (automatic)");
    send_text("Lights 1-5: ");
    for (lamp = 1U; lamp <= LIGHTS_COUNT; lamp++)
    {
        send_text(LIGHTS_get(lamp) ? "1" : "0");
    }
    send_line("");
    send_text("Dimmer: ");
    send_number(DIMMER_getLevel());
    send_line(" percent");
}

static void handle_remote_command(char *line)
{
    char *tokens[SMART_HOME_TOKEN_COUNT];
    uint8_t count;
    uint8_t number;
    uint8_t i;
    USER_ROLE_t role;
    char username[USER_STORE_NAME_SIZE];

    count = split_tokens(line, tokens, SMART_HOME_TOKEN_COUNT);
    if (count == 0U)
    {
        return;
    }
    uppercase_ascii(tokens[0]);

    if (strcmp(tokens[0], "HELP") == 0)
    {
        print_help();
        return;
    }

    if (strcmp(tokens[0], "LOGIN") == 0)
    {
        if (count != 3U)
        {
            send_line("Use: LOGIN <name> <password>");
            return;
        }
        role = USER_STORE_authenticate(tokens[1], tokens[2]);
        if (role == USER_ROLE_NONE)
        {
            failed_login();
            return;
        }
        remote_role = role;
        strcpy(remote_username, tokens[1]);
        failed_login_count = 0U;
        if (remote_role == USER_ROLE_ADMIN)
        {
            admin_allows_local = 0U;
            local_user_active = 0U;
            local_pin_length = 0U;
            send_line("Admin login successful. Local keypad is disabled.");
        }
        else
        {
            send_line("User login successful.");
        }
        return;
    }

    if (strcmp(tokens[0], "LOGOUT") == 0)
    {
        remote_role = USER_ROLE_NONE;
        remote_username[0] = '\0';
        admin_allows_local = 0U;
        send_line("Logged out.");
        return;
    }

    if (strcmp(tokens[0], "ADD") == 0)
    {
        if (!require_admin())
        {
            return;
        }
        if (count != 3U)
        {
            send_line("Use: ADD <name> <password>");
            return;
        }
        if (USER_STORE_addUser(tokens[1], tokens[2]))
        {
            send_line("User registered in EEPROM.");
        }
        else
        {
            send_line("Registration failed: duplicate, invalid, or full.");
        }
        return;
    }

    if (strcmp(tokens[0], "DEL") == 0)
    {
        if (!require_admin())
        {
            return;
        }
        if (count != 2U)
        {
            send_line("Use: DEL <name>");
            return;
        }
        send_line(USER_STORE_deleteUser(tokens[1]) ? "User deleted." : "User not found.");
        return;
    }

    if (strcmp(tokens[0], "LIST") == 0)
    {
        if (!require_admin())
        {
            return;
        }
        send_line("Registered users:");
        for (i = 0U; i < USER_STORE_MAX_USERS; i++)
        {
            if (USER_STORE_getUsername(i, username, sizeof(username)))
            {
                send_text("- ");
                send_line(username);
            }
        }
        return;
    }

    if (strcmp(tokens[0], "PASS") == 0)
    {
        if (!require_remote_login())
        {
            return;
        }
        if (count != 2U)
        {
            send_line("Use: PASS <new-password>");
            return;
        }
        send_line(USER_STORE_changePassword(remote_username, tokens[1]) ?
                  "Password changed." : "Password change failed.");
        return;
    }

    if (strcmp(tokens[0], "STATUS") == 0)
    {
        if (!require_remote_login())
        {
            return;
        }
        send_status();
        return;
    }

    if (strcmp(tokens[0], "LIGHT") == 0)
    {
        if (!require_remote_login())
        {
            return;
        }
        if (count != 3U || !parse_number(tokens[1], &number) ||
            number < 1U || number > LIGHTS_COUNT)
        {
            send_line("Use: LIGHT <1-5> <ON|OFF>");
            return;
        }
        uppercase_ascii(tokens[2]);
        if (strcmp(tokens[2], "ON") == 0)
        {
            LIGHTS_set(number, 1U);
        }
        else if (strcmp(tokens[2], "OFF") == 0)
        {
            LIGHTS_set(number, 0U);
        }
        else
        {
            send_line("State must be ON or OFF.");
            return;
        }
        send_line("Light updated.");
        return;
    }

    if (strcmp(tokens[0], "DIM") == 0)
    {
        if (!require_remote_login())
        {
            return;
        }
        if (count != 2U || !parse_number(tokens[1], &number) || number > 100U)
        {
            send_line("Use: DIM <0-100>");
            return;
        }
        DIMMER_setLevel(number);
        send_line("Dimmer level updated.");
        return;
    }

    if (strcmp(tokens[0], "DOOR") == 0)
    {
        if (!require_admin())
        {
            return;
        }
        if (count != 2U)
        {
            send_line("Use: DOOR <OPEN|CLOSE>");
            return;
        }
        uppercase_ascii(tokens[1]);
        if (strcmp(tokens[1], "OPEN") == 0)
        {
            SERVO_Set_angle(SMART_HOME_DOOR_OPEN_ANGLE);
            send_line("Door opened.");
        }
        else if (strcmp(tokens[1], "CLOSE") == 0)
        {
            SERVO_Set_angle(SMART_HOME_DOOR_CLOSED_ANGLE);
            send_line("Door closed.");
        }
        else
        {
            send_line("Door command must be OPEN or CLOSE.");
        }
        return;
    }

    if (strcmp(tokens[0], "LOCAL") == 0)
    {
        if (!require_admin())
        {
            return;
        }
        if (count != 2U)
        {
            send_line("Use: LOCAL <ENABLE|DISABLE>");
            return;
        }
        uppercase_ascii(tokens[1]);
        if (strcmp(tokens[1], "ENABLE") == 0)
        {
            admin_allows_local = 1U;
            send_line("Local keypad control enabled by admin.");
        }
        else if (strcmp(tokens[1], "DISABLE") == 0)
        {
            admin_allows_local = 0U;
            local_user_active = 0U;
            local_pin_length = 0U;
            send_line("Local keypad control disabled.");
        }
        else
        {
            send_line("Use ENABLE or DISABLE.");
        }
        return;
    }

    send_line("Unknown command. Send HELP.");
}

static void handle_local_key(KEYPAD_switch_t key)
{
    uint8_t lamp;

    if (remote_role == USER_ROLE_ADMIN && admin_allows_local == 0U)
    {
        display_message("Admin connected", "Local disabled");
        return;
    }

    if (local_user_active == 0U)
    {
        if (local_pin_length == 0U)
        {
            display_local_pin();
        }
        local_pin_input[local_pin_length++] = (char)('0' + (uint8_t)key);
        local_pin_input[local_pin_length] = '\0';
        display_local_pin();

        if (local_pin_length >= SMART_HOME_LOCAL_PIN_LENGTH)
        {
            if (USER_STORE_checkLocalPin(local_pin_input))
            {
                local_user_active = 1U;
                failed_login_count = 0U;
                local_pin_length = 0U;
                local_pin_input[0] = '\0';
                display_message("Local user OK", "4-8 lamps 9 dim");
            }
            else
            {
                local_pin_length = 0U;
                local_pin_input[0] = '\0';
                failed_login();
                display_message("Wrong local PIN", "Try again");
            }
        }
        return;
    }

    if (key >= KEYPAD_SW4 && key <= KEYPAD_SW8)
    {
        lamp = (uint8_t)(key - KEYPAD_SW4 + 1U);
        LIGHTS_toggle(lamp);
        display_status();
    }
    else if (key == KEYPAD_SW9)
    {
        local_dimmer_step = (uint8_t)((local_dimmer_step + 1U) % 5U);
        DIMMER_setLevel((uint8_t)(local_dimmer_step * 25U));
        display_status();
    }
    else if (key == KEYPAD_SW1)
    {
        local_user_active = 0U;
        local_pin_length = 0U;
        local_pin_input[0] = '\0';
        display_message("Local logout", "PIN to login");
    }
}

static void display_welcome(void)
{
    LCD_SendCommand(LCD_CLEAR_DISPLAY);
    LCD_Send_Str("Smart Home");
    LCD_SendCommand(LCD_LINE2);
    LCD_Send_Str("PIN / Bluetooth");
}

int main(void)
{
    char line[SMART_HOME_LINE_CAPACITY];
    uint8_t line_result;
    uint16_t sensor_timer = 0U;
    uint16_t status_timer = 0U;
    uint16_t local_idle_timer = 0U;
    KEYPAD_switch_t key;

    USER_STORE_init();
    LCD_init();
    KEYPAD_init(KEYPAD_INTERNAL_PULLUP);
    LIGHTS_init();
    DIMMER_init();
    TEMP_SENSOR_init();
    AC_CONTROL_init();
    ALARM_init();
    SERVO_init();
    SERVO_Set_angle(SMART_HOME_DOOR_CLOSED_ANGLE);
    BT_init();
    display_welcome();

    sei();
    send_line("ATmega32A Smart Home ready.");
    send_line("Use HELP. Default admin: admin / 1234.");

    while (1)
    {
        key = KEYPAD_getKey();
        if (key != KEYPAD_NO_KEY)
        {
            local_idle_timer = 0U;
            handle_local_key(key);
        }

        line_result = read_bt_line(line, sizeof(line));
        if (line_result == 1U)
        {
            handle_remote_command(line);
        }
        else if (line_result == 2U)
        {
            send_line("Input too long. Maximum line length is 63.");
        }

        sensor_timer = (uint16_t)(sensor_timer + SMART_HOME_LOOP_DELAY_MS);
        status_timer = (uint16_t)(status_timer + SMART_HOME_LOOP_DELAY_MS);
        if (sensor_timer >= SMART_HOME_SENSOR_PERIOD_MS)
        {
            current_temperature = TEMP_SENSOR_readCelsius();
            AC_CONTROL_update(current_temperature);
            sensor_timer = 0U;
        }

        if (local_user_active != 0U)
        {
            local_idle_timer = (uint16_t)(local_idle_timer + SMART_HOME_LOOP_DELAY_MS);
            if (local_idle_timer >= SMART_HOME_LOCAL_TIMEOUT_MS)
            {
                local_user_active = 0U;
                local_pin_length = 0U;
                local_pin_input[0] = '\0';
                display_message("Local timeout", "PIN to login");
            }
        }

        if (status_timer >= SMART_HOME_STATUS_PERIOD_MS &&
            local_pin_length == 0U)
        {
            display_status();
            status_timer = 0U;
        }

        _delay_ms(SMART_HOME_LOOP_DELAY_MS);
    }
}
