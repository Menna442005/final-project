# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  [[C:\Users\Dell\Documents\Codex\2026-10-23\new-chat\outputs\SmartHome_ATmega32A\out\D110\default.cmf]]
  [[C:\Users\Dell\Documents\Codex\2026-10-23\new-chat\outputs\SmartHome_ATmega32A\out\D110\default.hex]]
  [[C:\Users\Dell\Documents\Codex\2026-10-23\new-chat\outputs\SmartHome_ATmega32A\out\D110\default.hxl]]
  [[C:\Users\Dell\Documents\Codex\2026-10-23\new-chat\outputs\SmartHome_ATmega32A\out\D110\default.mum]]
  [[C:\Users\Dell\Documents\Codex\2026-10-23\new-chat\outputs\SmartHome_ATmega32A\out\D110\default.o]]
  [[C:\Users\Dell\Documents\Codex\2026-10-23\new-chat\outputs\SmartHome_ATmega32A\out\D110\default.sdb]]
  [[C:\Users\Dell\Documents\Codex\2026-10-23\new-chat\outputs\SmartHome_ATmega32A\out\D110\default.sym]]
  )
endif()
