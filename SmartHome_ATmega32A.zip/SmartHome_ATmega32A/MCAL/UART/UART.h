#ifndef UART_H_
#define UART_H_

#include <stdint.h>






#define UART_TX_BUFFER_SIZE     64
#define UART_RX_BUFFER_SIZE     64



void UART_init(uint32_t baud_rate);



uint8_t UART_sendByte(uint8_t data);



uint8_t UART_sendString(const char *str);



uint8_t UART_isTxBufferFull(void);


uint8_t UART_receiveByte(uint8_t *data);



uint8_t UART_isDataAvailable(void);


uint8_t UART_getRxOverflow(void);



void UART_clearRxOverflow(void);


#endif 