
#include "ADC.h"
#include "../../TOOLS.h"
#include "avr/interrupt.h"

static ADC_Callback_t   adc_interrupt;


ISR(ADC_vect){
 if(adc_interrupt != 0){
    adc_interrupt();
 }
}

void ADC_init(ADC_refrence_t refrence ,
              ADC_INPUT_channel_t input ,
              ADC_result_adj_t adjust ,
              ADC_prescaler_t prescale ,
              ADC_auto_trigger_t trigger
            )
{
   
    ADMUX  = refrence | adjust | input ;
    ADCSRA = prescale;
    if(trigger != ADC_NO_AUTO_TRIGGER){
     
        SET_BIT(ADCSRA,ADATE);
        SFIOR &=~(0b11100000);
        SFIOR |= trigger;
    }
    SET_BIT(ADCSRA,ADEN);
}



void ADC_set_Channel (ADC_INPUT_channel_t input){
   
    ADMUX &=~(0b00011111);
    ADMUX |= input;
}


void ADC_start_conversion (){
    SET_BIT(ADCSRA,ADSC);
}

void ADC_interrupt_init (ADC_Callback_t callback){
    adc_interrupt = callback;
}

void ADC_interrupt_enble(){
    SET_BIT(ADCSRA,ADIE);
}

void ADC_interrupt_Disable(){
    CLEAR_BIT(ADCSRA,ADIE);
}

uint8_t ADC_read_8bit(){
    while(READ_BIT(ADCSRA,ADSC));
    switch(READ_BIT(ADMUX,ADLAR)){
        case 0:

        return ((ADCL >> 2)| (( ADCH & 0b00000011)<<6));
        break;
        case 1 :
        return ADCH;
        break;
    }
    return (uint8_t)ADC;
}

uint16_t ADC_read_10bit(){

    while(READ_BIT(ADCSRA,ADSC));
    switch(READ_BIT(ADMUX,ADLAR)){
        case 0:
        return ADCL | (( ADCH & 0b00000011)<<8);
        break;
        case 1 :
        return (ADCH<<2)|( ADCL & 0b00000011);
        break;
    }
    return (uint8_t)ADC;
}
