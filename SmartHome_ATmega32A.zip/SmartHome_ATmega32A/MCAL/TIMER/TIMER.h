
#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>


typedef enum {
    TIMER0_NORMAL_MODE,
    TIMER0_CTC_MODE,
    TIMER0_FAST_PWM,
    TIMER0_PHASECORRECT_PWM
} TIMER0_Mode_t;


typedef enum {
    TIMER0_OCR0_DISCONNECTED,
    TIMER0_NON_PWM_OCR0_TOGGLE,
    TIMER0_NON_PWM_OCR0_SET,
    TIMER0_NON_PWM_OCR0_CLEAR,
    TIMER0_FAST_PWM_OCR0_CLEAR_OC_SET_BOTTOM,
    TIMER0_FAST_PWM_OCR0_SET_OC_CLEAR_BOTTOM,
    TIMER0_PHASE_PWM_OCR0_CLEAR_UP_SET_DOWN,
    TIMER0_PHASE_PWM_OCR0_SET_UP_CLEAR_DOWN
} TIMER0_compare_output_mode_t;


typedef enum {
    TIMER0_NO_CLK,
    TIMER0_NO_PRESCALER,
    TIMER0_PRESCALER_8,
    TIMER0_PRESCALER_64,
    TIMER0_PRESCALER_256,
    TIMER0_PRESCALER_1024,
    TIMER0_EXTERNAL_FALLING_EDGE,
    TIMER0_EXTERNAL_RISING_EDGE
} TIMER0_CLK_t;

typedef void (*callback_t)(void);


void TIMER0_init(TIMER0_Mode_t mode,
                 TIMER0_compare_output_mode_t cmpr,
                 TIMER0_CLK_t clk);


void TIMER0_setOCR0(uint8_t value);


void TIMER0_OVF_interrupt_init(callback_t ptr);

void TIMER0_OCR0_interrupt_init(callback_t ptr);


void TIMER0_OVF_interrupt_EN(void);


void TIMER0_OCR0_interrupt_EN(void);


void TIMER0_OVF_interrupt_disable(void);


void TIMER0_OCR0_interrupt_disable(void);




typedef enum {
    TIMER1_NORMAL_MODE                         = 0,
    TIMER1_PWM_PHASE_CORRECT_8BIT              = 1,
    TIMER1_PWM_PHASE_CORRECT_9BIT              = 2,
    TIMER1_PWM_PHASE_CORRECT_10BIT             = 3,
    TIMER1_CTC_OCR1A                            = 4,
    TIMER1_FAST_PWM_8BIT                       = 5,
    TIMER1_FAST_PWM_9BIT                       = 6,
    TIMER1_FAST_PWM_10BIT                      = 7,
    TIMER1_PWM_PHASE_FREQUENCY_CORRECT_ICR1    = 8,
    TIMER1_PWM_PHASE_FREQUENCY_CORRECT_OCR1A   = 9,
    TIMER1_PWM_PHASE_CORRECT_ICR1              = 10,
    TIMER1_PWM_PHASE_CORRECT_OCR1A             = 11,
    TIMER1_CTC_ICR1                             = 12,
  /
    TIMER1_FAST_PWM_ICR1                       = 14,
    TIMER1_FAST_PWM_OCR1A                      = 15
} TIMER1_Mode_t;

typedef enum {
    TIMER1_OCR1A_DISCONNECTED                    ,

    /* Normal and CTC modes */
    TIMER1_OCR1A_NON_PWM_TOGGLE                  ,
    TIMER1_OCR1A_NON_PWM_CLEAR                   ,
    TIMER1_OCR1A_NON_PWM_SET                     ,

    /* Fast PWM modes */
    TIMER1_OCR1A_FAST_PWM_TOGGLE_ON_TOP          ,
    TIMER1_OCR1A_FAST_PWM_NON_INVERTING          ,
    TIMER1_OCR1A_FAST_PWM_INVERTING              ,

    /* Phase-correct and phase/frequency-correct PWM modes */
    TIMER1_OCR1A_PHASE_PWM_TOGGLE_ON_TOP         ,
    TIMER1_OCR1A_PHASE_PWM_NON_INVERTING         ,
    TIMER1_OCR1A_PHASE_PWM_INVERTING             
} TIMER1_OCR1A_mode_t;



typedef enum {
    TIMER1_OCR1B_DISCONNECTED           ,

    /* Normal and CTC modes */
    TIMER1_OCR1B_NON_PWM_TOGGLE         ,
    TIMER1_OCR1B_NON_PWM_CLEAR          ,
    TIMER1_OCR1B_NON_PWM_SET            ,

    /* Fast PWM modes */
    TIMER1_OCR1B_FAST_PWM_NON_INVERTING ,
    TIMER1_OCR1B_FAST_PWM_INVERTING     ,

    /* Phase-correct and phase/frequency-correct PWM modes */
    TIMER1_OCR1B_PHASE_PWM_NON_INVERTING,
    TIMER1_OCR1B_PHASE_PWM_INVERTING    
} TIMER1_OCR1B_mode_t;


typedef enum {
    TIMER1_NO_CLK,
    TIMER1_NO_PRESCALER,
    TIMER1_PRESCALER_8,
    TIMER1_PRESCALER_64,
    TIMER1_PRESCALER_256,
    TIMER1_PRESCALER_1024,
    TIMER1_EXTERNAL_FALLING_EDGE,
    TIMER1_EXTERNAL_RISING_EDGE
} TIMER1_CLK_t;


void TIMER1_init(TIMER1_Mode_t mode,
                 TIMER1_OCR1A_mode_t oca,
                 TIMER1_OCR1B_mode_t ocb, 
                 TIMER1_CLK_t clk);


void TIMER1_setOCR1A(uint16_t value);


void TIMER1_setOCR1B(uint16_t value);


void TIMER1_setICR1(uint16_t value);


void TIMER1_OVF_interrupt_init(callback_t ptr);


void TIMER1_OCR1A_interrupt_init(callback_t ptr);


void TIMER1_OCR1B_interrupt_init(callback_t ptr);


void TIMER1_OVF_interrupt_EN(void);

void TIMER1_OCR1A_interrupt_EN(void);

void TIMER1_OCR1B_interrupt_EN(void);


void TIMER1_OVF_interrupt_disable(void);


void TIMER1_OCR1A_interrupt_disable(void);


void TIMER1_OCR1B_interrupt_disable(void);


#endif 
