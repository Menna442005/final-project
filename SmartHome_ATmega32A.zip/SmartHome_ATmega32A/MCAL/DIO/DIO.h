
#ifndef DIO_H
#define DIO_H


#include "../GPIO/GPIO.h"


typedef enum {
    DIO_LOW,
    DIO_HIGH
}DIO_boot_t;

void DIO_set_pin(GPIO_pin_t pin);

void DIO_write_pin(GPIO_pin_t pin,DIO_boot_t value);

void DIO_clear_pin(GPIO_pin_t pin);

void DIO_toggle_pin(GPIO_pin_t pin);

DIO_boot_t DIO_read_pin(GPIO_pin_t pin);

DIO_boot_t DIO_is_Set(GPIO_pin_t pin);

#endif