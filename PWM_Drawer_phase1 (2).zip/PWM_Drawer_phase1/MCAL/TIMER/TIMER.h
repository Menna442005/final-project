/**
 * @file TIMER.h
 * @brief Timer0 and Timer1 driver interfaces for the AVR ATmega32A timer peripherals.
 *
 * Provides configuration types for Timer0 waveform generation, OC0 compare
 * output behavior, clock source selection, compare value loading, and Timer0
 * interrupt callback registration. Also provides Timer1 configuration types
 * and prototypes for WGM13:0 modes, OC1A/OC1B compare output behavior,
 * Timer1 top/compare register loading, and Timer1 interrupt control.
 */
#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>

/** @brief Selects the Timer0 waveform generation mode. */
typedef enum {
    TIMER0_NORMAL_MODE,
    TIMER0_CTC_MODE,
    TIMER0_FAST_PWM,
    TIMER0_PHASECORRECT_PWM
} TIMER0_Mode_t;

/** @brief Selects how the OC0 pin behaves on compare match. */
typedef enum {
    TIMER0_OCR0_DISCONNECTED,
    TIMER0_NON_PWM_OCR0_TOGGLE,
    TIMER0_NON_PWM_OCR0_SET,
    TIMER0_NON_PWM_OCR0_CLEAR,
    TIMER0_FAST_PWM_OCR0_CLEAR_OC_SET_BOTTOM,
    TIMER0_FAST_PWM_OCR0_SET_OC_CLEAR_BOTTOM,
    TIMER0_PHASE_PWM_OCR0_CLEAR_UP_SET_DOWN,
    TIMER0_PHASE_PWM_OCR0_SET_UP_CLEAR_DOWN
} TIMER0_compare_output_mode_t;

/** @brief Selects the Timer0 clock source and prescaler. */
typedef enum {
    TIMER0_NO_CLK,
    TIMER0_NO_PRESCALER,
    TIMER0_PRESCALER_8,
    TIMER0_PRESCALER_64,
    TIMER0_PRESCALER_256,
    TIMER0_PRESCALER_1024,
    TIMER0_EXTERNAL_FALLING_EDGE,
    TIMER0_EXTERNAL_RISING_EDGE
} TIMER0_CLK_t;

/** @brief Function pointer type used for Timer0 and Timer1 interrupt callbacks. */
typedef void (*callback_t)(void);

/** @brief Configures Timer0 mode, compare output mode, and clock source. */
void TIMER0_init(TIMER0_Mode_t mode,
                 TIMER0_compare_output_mode_t cmpr,
                 TIMER0_CLK_t clk);

/** @brief Writes a compare value to the Timer0 OCR0 register. */
void TIMER0_setOCR0(uint8_t value);

/** @brief Registers a callback for the Timer0 overflow interrupt. */
void TIMER0_OVF_interrupt_init(callback_t ptr);

/** @brief Registers a callback for the Timer0 output compare interrupt. */
void TIMER0_OCR0_interrupt_init(callback_t ptr);

/** @brief Enables the Timer0 overflow interrupt. */
void TIMER0_OVF_interrupt_EN(void);

/** @brief Enables the Timer0 output compare interrupt. */
void TIMER0_OCR0_interrupt_EN(void);

/** @brief Disables the Timer0 overflow interrupt. */
void TIMER0_OVF_interrupt_disable(void);

/** @brief Disables the Timer0 output compare interrupt. */
void TIMER0_OCR0_interrupt_disable(void);




/**
 * @brief Selects a Timer1 waveform generation mode.
 *
 * Enumerator values match the ATmega32A WGM13:0 bit encoding split between
 * TCCR1A and TCCR1B. Mode 13 is reserved by the device and is intentionally
 * not exposed.
 */
typedef enum {
    TIMER1_NORMAL_MODE                         = 0,
    TIMER1_PWM_PHASE_CORRECT_8BIT              = 1,
    TIMER1_PWM_PHASE_CORRECT_9BIT              = 2,
    TIMER1_PWM_PHASE_CORRECT_10BIT             = 3,
    TIMER1_CTC_OCR1A                            = 4,
    TIMER1_FAST_PWM_8BIT                       = 5,
    TIMER1_FAST_PWM_9BIT                       = 6,
    TIMER1_FAST_PWM_10BIT                      = 7,
    TIMER1_PWM_PHASE_FREQUENCY_CORRECT_ICR1    = 8,
    TIMER1_PWM_PHASE_FREQUENCY_CORRECT_OCR1A   = 9,
    TIMER1_PWM_PHASE_CORRECT_ICR1              = 10,
    TIMER1_PWM_PHASE_CORRECT_OCR1A             = 11,
    TIMER1_CTC_ICR1                             = 12,
    /* WGM mode 13 is reserved. */
    TIMER1_FAST_PWM_ICR1                       = 14,
    TIMER1_FAST_PWM_OCR1A                      = 15
} TIMER1_Mode_t;

/**
 * @brief Selects the OC1A pin behavior on Timer1 compare match.
 *
 * The driver translates each option to COM1A1:0. Separate names are provided
 * because the same register encoding has different meanings in non-PWM,
 * Fast PWM, and phase-correct PWM modes.
 */
typedef enum {
    TIMER1_OCR1A_DISCONNECTED                    ,

    /* Normal and CTC modes */
    TIMER1_OCR1A_NON_PWM_TOGGLE                  ,
    TIMER1_OCR1A_NON_PWM_CLEAR                   ,
    TIMER1_OCR1A_NON_PWM_SET                     ,

    /* Fast PWM modes */
    TIMER1_OCR1A_FAST_PWM_TOGGLE_ON_TOP          ,
    TIMER1_OCR1A_FAST_PWM_NON_INVERTING          ,
    TIMER1_OCR1A_FAST_PWM_INVERTING              ,

    /* Phase-correct and phase/frequency-correct PWM modes */
    TIMER1_OCR1A_PHASE_PWM_TOGGLE_ON_TOP         ,
    TIMER1_OCR1A_PHASE_PWM_NON_INVERTING         ,
    TIMER1_OCR1A_PHASE_PWM_INVERTING             
} TIMER1_OCR1A_mode_t;


/**
 * @brief Selects the OC1B pin behavior on Timer1 compare match.
 *
 * The driver translates each option to COM1B1:0. OC1B does not support the
 * OCR1A-only toggle-on-TOP behavior used by some Timer1 modes.
 */
typedef enum {
    TIMER1_OCR1B_DISCONNECTED           ,

    /* Normal and CTC modes */
    TIMER1_OCR1B_NON_PWM_TOGGLE         ,
    TIMER1_OCR1B_NON_PWM_CLEAR          ,
    TIMER1_OCR1B_NON_PWM_SET            ,

    /* Fast PWM modes */
    TIMER1_OCR1B_FAST_PWM_NON_INVERTING ,
    TIMER1_OCR1B_FAST_PWM_INVERTING     ,

    /* Phase-correct and phase/frequency-correct PWM modes */
    TIMER1_OCR1B_PHASE_PWM_NON_INVERTING,
    TIMER1_OCR1B_PHASE_PWM_INVERTING    
} TIMER1_OCR1B_mode_t;

/** @brief Selects the Timer1 clock source and prescaler. */
typedef enum {
    TIMER1_NO_CLK,
    TIMER1_NO_PRESCALER,
    TIMER1_PRESCALER_8,
    TIMER1_PRESCALER_64,
    TIMER1_PRESCALER_256,
    TIMER1_PRESCALER_1024,
    TIMER1_EXTERNAL_FALLING_EDGE,
    TIMER1_EXTERNAL_RISING_EDGE
} TIMER1_CLK_t;

/**
 * @brief Configures Timer1 waveform mode, OC1A/OC1B output modes, and clock source.
 *
 * @param mode Timer1 waveform generation mode using the WGM13:0 encoding.
 * @param oca OC1A compare output behavior using COM1A1:0 encoding.
 * @param ocb OC1B compare output behavior using COM1B1:0 encoding.
 * @param clk Timer1 clock source or prescaler selection using CS12:0 encoding.
 */
void TIMER1_init(TIMER1_Mode_t mode,
                 TIMER1_OCR1A_mode_t oca,
                 TIMER1_OCR1B_mode_t ocb, 
                 TIMER1_CLK_t clk);

/**
 * @brief Writes a compare value to the Timer1 OCR1A register.
 *
 * OCR1A is also used as TOP in Timer1 modes that select OCR1A as the top value.
 * The API accepts the full 16-bit width of the OCR1A register.
 */
void TIMER1_setOCR1A(uint16_t value);

/**
 * @brief Writes a compare value to the Timer1 OCR1B register.
 *
 * The API accepts the full 16-bit width of the OCR1B register.
 */
void TIMER1_setOCR1B(uint16_t value);

/**
 * @brief Writes a top value to the Timer1 ICR1 register.
 *
 * ICR1 is used as TOP in Timer1 modes that select ICR1 as the top value. The
 * API accepts the full 16-bit width of the ICR1 register.
 */
void TIMER1_setICR1(uint16_t value);

/** @brief Registers a callback for the Timer1 overflow interrupt. */
void TIMER1_OVF_interrupt_init(callback_t ptr);

/** @brief Registers a callback for the Timer1 output compare A interrupt. */
void TIMER1_OCR1A_interrupt_init(callback_t ptr);

/** @brief Registers a callback for the Timer1 output compare B interrupt. */
void TIMER1_OCR1B_interrupt_init(callback_t ptr);

/** @brief Enables the Timer1 overflow interrupt. */
void TIMER1_OVF_interrupt_EN(void);

/** @brief Enables the Timer1 output compare A interrupt. */
void TIMER1_OCR1A_interrupt_EN(void);

/** @brief Enables the Timer1 output compare B interrupt. */
void TIMER1_OCR1B_interrupt_EN(void);

/** @brief Disables the Timer1 overflow interrupt. */
void TIMER1_OVF_interrupt_disable(void);

/** @brief Disables the Timer1 output compare A interrupt. */
void TIMER1_OCR1A_interrupt_disable(void);

/** @brief Disables the Timer1 output compare B interrupt. */
void TIMER1_OCR1B_interrupt_disable(void);


#endif /* TIMER_H */
