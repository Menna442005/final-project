/**
 * @file ADC.h
 * @brief Analog-to-digital converter interface for the AVR peripheral.
 *
 * Supports single-ended and differential inputs, selectable references,
 * result alignment, clock prescaling, auto triggering, and interrupts.
 */
#ifndef ADC_H
#define ADC_H
#include <avr/io.h>
/*
AREF 
VCC
2.54 V

10 BIT (0  - 1023)         
VCC     0V - 5V     1- (5V/1023) --> 4.89 mV resolution  20 uV
AREF    0V - AREF(3.3V  IF THE INPUT ON THE AREF VOLT  WAS 3.3)  3300 mv / 1023 --> 3.22 mv
2.56 V  0V - 2.56V  (2560/1023)  --> 2.5mv



VCC --> 5V
VDD --> 5V
VSS --> GND


ADC1 - ADC1 GAIN
*/
/** @brief Selects the voltage used as the ADC full-scale reference. */
typedef enum {
ADC_AREF_REFRENCE =0b00000000,
ADC_AVCC_REFRENCE =0b01000000,
ADC_2056mV_REFRENCE = 0b11000000,

} ADC_refrence_t;

/** @brief Selects an ADC input channel or differential input pair and gain. */
typedef enum {
    ADC_SINGLE_ENDED_ADC0 = 0b0000,
    ADC_SINGLE_ENDED_ADC1 = 0b0001,
    ADC_SINGLE_ENDED_ADC2 = 0b0010,
    ADC_SINGLE_ENDED_ADC3 = 0b0011,
    ADC_SINGLE_ENDED_ADC4 = 0b0100,
    ADC_SINGLE_ENDED_ADC5 = 0b0101,
    ADC_SINGLE_ENDED_ADC6 = 0b0110,
    ADC_SINGLE_ENDED_ADC7 = 0b0111,
    ADC_DIF_ADC0_ADC0_10X =0b01000,
    ADC_DIF_ADC1_ADC0_10X =0b01001,
    ADC_DIF_ADC0_ADC0_200X =0b01010,
    ADC_DIF_ADC1_ADC0_200X =0b01011,
    ADC_DIF_ADC2_ADC2_10X =0b01100,
    ADC_DIF_ADC3_ADC2_10X =0b01101,
    ADC_DIF_ADC2_ADC2_200X =0b01110,
    ADC_DIF_ADC3_ADC2_200X =0b01111,
    ADC_DIF_ADC0_ADC1_1X =0b10000,
    ADC_DIF_ADC1_ADC1_1X =0b10001,
    ADC_DIF_ADC2_ADC1_1X =0b10010,
    ADC_DIF_ADC3_ADC1_1X =0b10011,
    ADC_DIF_ADC4_ADC1_1X =0b10100,
    ADC_DIF_ADC5_ADC1_1X =0b10101,
    ADC_DIF_ADC6_ADC1_1X =0b10110,
    ADC_DIF_ADC7_ADC1_1X =0b10111,
    ADC_DIF_ADC0_ADC2_1X =0b11000,
    ADC_DIF_ADC1_ADC2_1X =0b11001,
    ADC_DIF_ADC2_ADC2_1X =0b11010,
    ADC_DIF_ADC3_ADC2_1X =0b11011,
    ADC_DIF_ADC4_ADC2_1X =0b11100,
    ADC_DIF_ADC5_ADC2_1X =0b11101,
    ADC_SINGLE_ENDED_1220mV = 0b11110,
    ADC_SINGLE_ENDED_GND = 0b11111,
    
}ADC_INPUT_channel_t;

/** @brief Selects the alignment of the conversion result in ADC registers. */
typedef enum {
    ADC_RESULT_RIGHT_ADJUST =0b000000,
    ADC_RESULT_LEFT_ADJUST= 0b100000
}ADC_result_adj_t;
/**
 * 16MHZ
 * ADC 50KHZ - 200KHZ
 * PRESCALER
 * 2      - 4     - 8    - 16   - 32      - 64      - 128
 * 8MHZ   - 4MHZ  - 2MHZ - 1MHZ - 500KHZ  - 250KHZ  - 125KHZ
 */
/** @brief Selects the division ratio between the CPU clock and ADC clock. */
typedef enum {
ADC_PRESCALER_2 = 0b001,
ADC_PRESCALER_4 = 0b010,
ADC_PRESCALER_8 ,
ADC_PRESCALER_16 ,
ADC_PRESCALER_32 ,
ADC_PRESCALER_64 ,
ADC_PRESCALER_128 
}ADC_prescaler_t;
/*
0 0 0 Free Running mode
0 0 1 Analog Comparator
0 1 0 External Interrupt Request 0
0 1 1 Timer/Counter0 Compare Match
1 0 0 Timer/Counter0 Overflow
1 0 1 Timer/Counter1 Compare Match B
1 1 0 Timer/Counter1 Overflow
1 1 1 Timer/Counter1 Capture Event
*/
/** @brief Selects the hardware event used for automatic conversion triggering. */
typedef enum {
ADC_FREE_RUNNING_TRIGGER = 0b00000000,
ADC_ANALOG_COMPARATOR_TRIGGER = 0b00100000,
ADC_EXTERNAL_INTERRUPT_TRIGGER = 0b01000000,
ADC_TIMER0_COMPARE_MATCH_TRIGGER = 0b01100000,
ADC_TIMER0_OVERFLOW_TRIGGER = 0b10000000,
ADC_TIMER1_COMPARE_MATCH_B_TRIGGER = 0b10100000,
ADC_TIMER1_OVERFLOW_TRIGGER = 0b11000000,
ADC_TIMER1_CAPTURE_EVENT_TRIGGER = 0b11100000,
ADC_NO_AUTO_TRIGGER = -1
}ADC_auto_trigger_t;

/**
 * @brief Configure and enable the ADC peripheral.
 * @param refrence Voltage reference selection.
 * @param input Input channel or differential pair.
 * @param adjust Conversion-result alignment.
 * @param prescale ADC clock division ratio.
 * @param tigger Trigger source, or ADC_NO_AUTO_TRIGGER.
 */
void ADC_init(ADC_refrence_t refrence ,
              ADC_INPUT_channel_t input ,
              ADC_result_adj_t adjust ,
              ADC_prescaler_t prescale ,
              ADC_auto_trigger_t tigger
            );
/** @brief Select a new input without changing other ADMUX fields. @param input New ADC input. */
void ADC_set_Channel (ADC_INPUT_channel_t input);
/** @brief Start an ADC conversion by setting the ADSC control bit. */
void ADC_start_conversion ();
/** @brief Callback type used by the conversion-complete interrupt. */
typedef void (*ADC_Callback_t)(void);

/**
 * @brief Read the most significant eight bits of a left-adjusted conversion.
 * @return The conversion value stored in ADCH.
 * @pre ADC_RESULT_LEFT_ADJUST must be selected during ADC initialization.
 */
uint8_t ADC_read_8bit();
/** @brief Read the complete ADC value. @return The 10-bit result in a uint16_t. */
uint16_t ADC_read_10bit();
/** @brief Register the interrupt callback. @param callback Function called from the ADC ISR. */
void ADC_interrupt_init (ADC_Callback_t callback);
/** @brief Enable the ADC conversion-complete interrupt. */
void ADC_interrupt_enble();
/** @brief Disable the ADC conversion-complete interrupt. */
void ADC_interrupt_Disable();

#endif /* ADC_H */
