# PWM Drawer

This project keeps the `D110` folder organization and AVR C style and uses the ATmega32A at 16 MHz. The application measures one PWM period and high time with Timer1 input capture, then draws the signal and its frequency, duty cycle, and cycle time on a 128x64 KS0108 graphical LCD. GPIO pin setup and display I/O use the supplied `MCAL/GPIO`, `MCAL/DIO`, and `TOOLS.h` drivers.

## Files

- `main.c` - PWM generation, input capture, and scope display, built on the provided `D110` Timer0 driver
- `MCAL/TIMER/` and `TOOLS.h` - reused from `D110.zip`
- `MCAL/GPIO/` and `MCAL/DIO/` - ATmega32A pin and digital-I/O drivers
- `HAL/KEYPAD/`, `HAL/LCD/`, `HAL/LEDS/`, `HAL/SEG/`, `MCAL/ADC/` - retained project modules in the original layout
- `cmake/` and `.vscode/` - project settings and build configuration
- `HAL/GLCD/GLCD.c` and `HAL/GLCD/GLCD.h` - KS0108 display driver
- `CONFIG.h` - CPU clock configuration
- `Proteus_Wiring.md` - complete component and connection list for the Proteus schematic

## Build

Compile `main.c`, `HAL/GLCD/GLCD.c`, and `MCAL/TIMER/TIMER.c` with an AVR-GCC toolchain for `atmega32a`, with the project root included for headers and `F_CPU=16000000UL`. Load the resulting Intel HEX file into the ATmega32A simulation model and set its clock to 16 MHz.

The internal PWM is available at PB3/OC0. Route the chosen signal to PD6/ICP1 using the DPDT source switch described in `Proteus_Wiring.md`.

## Phase 1 corrections

- Timer1 overflow handling now uses the callback already provided by `MCAL/TIMER/TIMER.c`; `main.c` only owns the input-capture ISR. This avoids defining `TIMER1_OVF_vect` twice.
- Input-capture timestamps account for a Timer1 overflow flag that is pending when the higher-priority capture ISR runs.
- Frequency is formatted to two decimal places in kHz, and period/duty calculations use wider intermediate arithmetic to avoid 32-bit multiplication overflow.

The code has been statically reviewed, but it has **not yet been compiled with AVR-GCC or run in Proteus** in this environment. Those checks remain part of the next phase.

- GLCD initialization now disables the ATmega32A JTAG interface using the required consecutive JTD writes, so Port C pins used by the display can function as GPIO.
