# PWM Drawer - Proteus wiring

This is the schematic connection sheet for the Proteus ISIS design. The original `D110.zip` contains no ISIS design, and Proteus is not installed in this workspace, so this file documents the circuit instead of pretending to be an openable `.dsn` project.

## Parts

- ATMEGA32A, clock set to 16 MHz
- PG12864 / KS0108 128x64 graphical LCD
- SW-DPDT switch for selecting the signal source
- 5 V and GND terminals
- External PWM source (for example, a CLOCK/PULSE generator)

## Connections

| ATmega32A | Connect to |
|---|---|
| PA0-PA7 | GLCD D0-D7 |
| PC0 | GLCD CS1 |
| PC1 | GLCD CS2 |
| PC2 | GLCD DI / RS |
| PC3 | GLCD R/W |
| PC4 | GLCD E |
| PC5 | GLCD RESET |
| PD6 / ICP1 | DPDT pole A common (selected PWM signal) |
| PB3 / OC0 | DPDT pole A internal-signal contact |
| External PWM output | DPDT pole A external-signal contact |
| PD2 | DPDT pole B common; internal position to GND, external position to +5 V |
| VCC, AVCC | +5 V |
| GND | GND |

Connect the GLCD supply and contrast pins per the selected Proteus model. Disable the ATmega32A JTAG interface on Port C; firmware also disables JTAG during GLCD initialization. Tie all grounds together. The external PWM level must stay within 0-5 V.

Set the ATmega32A program property to the compiled `PWM_Drawer.hex` and clock frequency to 16 MHz. Position the DPDT switch to select either the PB3 internally generated PWM or the external source; the second pole reports the selected source on screen.

## Measurement details

Timer0 generates an approximately 976.6 Hz, 50% duty PWM signal on PB3. Timer1 captures rising and falling edges at PD6/ICP1 using a 2 MHz timer clock. The display shows frequency in kHz, duty cycle, period in microseconds, source, and one measured cycle.

## Suggested verification cases

| Test | Source | Input signal | Expected display/check |
|---|---|---|---|
| 1 | Internal | Timer0 PWM, nominally 976.6 Hz, 50% | Approximately 0.98 kHz, 50%, 1.024 ms |
| 2 | External | 1 kHz, 25% duty, 0-5 V | Approximately 1.00 kHz, 25%, 1.000 ms |
| 3 | External | 2 kHz, 75% duty, 0-5 V | Approximately 2.00 kHz, 75%, 0.500 ms |
| 4 | External | 500 Hz, 50% duty, 0-5 V | Approximately 0.50 kHz, 50%, 2.000 ms |
| 5 | External | No signal | `NO PWM` after the capture state is reset; timeout behavior still needs implementation/verification |

For each external test, connect the generator ground to circuit ground and keep the signal between 0 V and 5 V. Confirm the generator's actual frequency and duty settings before comparing them with the LCD.
