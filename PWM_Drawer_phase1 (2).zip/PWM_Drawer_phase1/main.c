/**
 * @file main.c
 * @author AMIT
 * @brief Measure a PWM signal and draw its period on a 128x64 GLCD.
 *
 * Timer1 input capture measures the signal period and high time. Timer0
 * generates an internal PWM signal on PB3 for the internal-source option.
 */
#include "CONFIG.h"
#include "HAL/GLCD/GLCD.h"
#include "MCAL/DIO/DIO.h"
#include "MCAL/GPIO/GPIO.h"
#include "MCAL/TIMER/TIMER.h"
#include <avr/interrupt.h>
#include <avr/io.h>
#include <util/delay.h>

#define SOURCE_SWITCH       GPIO_PD2
#define PWM_OUTPUT          GPIO_PB3
#define TICKS_PER_SECOND    (F_CPU / 8UL)

static volatile uint32_t timer1_overflows;
static volatile uint32_t measured_period;
static volatile uint32_t measured_high;
static volatile uint8_t capture_state;
static volatile uint8_t measurement_ready;

/* Timer1 overflow vector is owned by MCAL/TIMER/TIMER.c.
 * This callback extends the 16-bit Timer1 counter to a 32-bit time base. */
static void Timer1_Overflow_Callback(void)
{
    timer1_overflows++;
}

ISR(TIMER1_CAPT_vect)
{
    uint16_t captured_low = ICR1;
    uint32_t captured_overflows = timer1_overflows;
    uint32_t captured;

    /* If Timer1 overflowed just before this capture, its overflow ISR may
     * still be pending because the capture ISR has higher priority. */
    if ((TIFR & (1 << TOV1)) && (captured_low < 0x8000U)) {
        captured_overflows++;
    }

    captured = (captured_overflows << 16) | captured_low;

    if (capture_state == 0) {
        /* First rising edge: establish the start of one complete cycle. */
        timer1_overflows = 0;
        TCNT1 = 0;
        TIFR = (1 << TOV1); /* Clear any overflow pending before the baseline. */
        TCCR1B &= ~(1 << ICES1); /* Capture the falling edge next. */
        capture_state = 1;
    } else if (capture_state == 1) {
        measured_high = captured;
        TCCR1B |= (1 << ICES1); /* Capture the next rising edge. */
        capture_state = 2;
    } else {
        measured_period = captured;
        measurement_ready = 1;
        capture_state = 0;
    }
}

static void PWM_init(void)
{
    GPIO_Pin_Mode(PWM_OUTPUT, GPIO_DIO_OUTPUT);
    TIMER0_setOCR0(127);
    TIMER0_init(TIMER0_FAST_PWM,
                TIMER0_FAST_PWM_OCR0_CLEAR_OC_SET_BOTTOM,
                TIMER0_PRESCALER_64);
}

static void Capture_init(void)
{
    GPIO_Pin_Mode(SOURCE_SWITCH, GPIO_DIO_INPUT_PULLUP);
    GPIO_Pin_Mode(GPIO_PD6, GPIO_DIO_INPUT);
    TCCR1A = 0;
    TCNT1 = 0;
    TIFR = (1 << ICF1) | (1 << TOV1);

    /* Register overflow handling through the existing Timer1 driver.
     * Do not define TIMER1_OVF_vect again in this application file. */
    TIMER1_OVF_interrupt_init(Timer1_Overflow_Callback);
    TIMER1_OVF_interrupt_EN();
    TIMSK |= (1 << TICIE1);

    /* Start Timer1 with input-capture noise cancellation and /8 prescaling. */
    TCCR1B = (1 << ICNC1) | (1 << ICES1) | (1 << CS11);
}

static void Scope_draw(uint32_t period, uint32_t high, uint8_t internal)
{
    uint32_t frequency_centi_khz = 0;
    uint32_t duty = 0;
    uint32_t cycle_us = 0;
    uint8_t high_width = 0;
    uint8_t x;

    if (period != 0) {
        if (high > period) high = period;

        /* Timer1 runs at F_CPU / 8. Keep two decimal places in kHz. */
        frequency_centi_khz =
            (((TICKS_PER_SECOND / 1000UL) * 100UL) + (period / 2UL)) / period;
        duty = (uint32_t)(((uint64_t)high * 100ULL) / period);
        cycle_us = (uint32_t)((((uint64_t)period * 1000000ULL) +
                               (TICKS_PER_SECOND / 2UL)) / TICKS_PER_SECOND);
        high_width = (uint8_t)((duty * 96UL) / 100UL);
    }

    GLCD_clear();

    /* Frequency: display two decimal places, e.g. 0.98 KHz. */
    GLCD_text(0, 0, "F:");
    GLCD_number(12, 0, frequency_centi_khz / 100UL);
    GLCD_text(24, 0, ".");
    if ((frequency_centi_khz % 100UL) < 10UL) {
        GLCD_text(30, 0, "0");
        GLCD_number(36, 0, frequency_centi_khz % 100UL);
    } else {
        GLCD_number(30, 0, frequency_centi_khz % 100UL);
    }
    GLCD_text(48, 0, "KHZ");

    GLCD_text(78, 0, "D:");
    GLCD_number(90, 0, duty);
    GLCD_text(112, 0, "%");

    GLCD_text(0, 10, "T:");
    GLCD_number(12, 10, cycle_us);
    GLCD_text(42, 10, "US");
    GLCD_text(78, 10, internal ? "INT" : "EXT");

    /* Draw one complete PWM cycle: high level, falling edge, low level. */
    for (x = 12; x < 109; x++) GLCD_pixel(x, 62, 1);

    if (period != 0) {
        uint8_t edge = (uint8_t)(12 + high_width);

        for (x = 12; x < edge; x++) GLCD_pixel(x, 28, 1);
        for (x = edge; x < 109; x++) GLCD_pixel(x, 56, 1);

        for (x = 29; x < 56; x++) {
            GLCD_pixel(12, x, 1);
            GLCD_pixel(edge, x, 1);
            GLCD_pixel(109, x, 1);
        }
    } else {
        GLCD_text(42, 38, "NO PWM");
    }

    GLCD_refresh();
}

int main(void)
{
    uint32_t display_period = 0;
    uint32_t display_high = 0;
    uint8_t internal_source;
    uint8_t update_display = 1;

    GLCD_init();
    Capture_init();
    PWM_init();
    sei();

    while (1)
    {
        internal_source = (DIO_read_pin(SOURCE_SWITCH) == DIO_LOW) ? 1 : 0;
        if (measurement_ready) {
            uint8_t interrupt_state = SREG;
            cli();
            display_period = measured_period;
            display_high = measured_high;
            measurement_ready = 0;
            SREG = interrupt_state;
            update_display = 1;
        }

        if (update_display) {
            Scope_draw(display_period, display_high, internal_source);
            update_display = 0;
        }
        _delay_ms(20);
    }

    return 0;
}
