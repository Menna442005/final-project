set(CMAKE_HOST_SYSTEM "Windows-10.0.22000")
set(CMAKE_HOST_SYSTEM_NAME "Windows")
set(CMAKE_HOST_SYSTEM_VERSION "10.0.22000")
set(CMAKE_HOST_SYSTEM_PROCESSOR "")

include("C:/Users/Dell/Downloads/PWM_Drawer_phase1/cmake/D110/default/.generated/toolchain.cmake")

set(CMAKE_SYSTEM "Generic")
set(CMAKE_SYSTEM_NAME "Generic")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
