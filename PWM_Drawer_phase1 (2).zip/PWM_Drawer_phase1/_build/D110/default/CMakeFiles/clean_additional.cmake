# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  [[C:\Users\Dell\Downloads\PWM_Drawer_phase1\out\D110\default.cmf]]
  [[C:\Users\Dell\Downloads\PWM_Drawer_phase1\out\D110\default.hex]]
  [[C:\Users\Dell\Downloads\PWM_Drawer_phase1\out\D110\default.hxl]]
  [[C:\Users\Dell\Downloads\PWM_Drawer_phase1\out\D110\default.mum]]
  [[C:\Users\Dell\Downloads\PWM_Drawer_phase1\out\D110\default.o]]
  [[C:\Users\Dell\Downloads\PWM_Drawer_phase1\out\D110\default.sdb]]
  [[C:\Users\Dell\Downloads\PWM_Drawer_phase1\out\D110\default.sym]]
  )
endif()
