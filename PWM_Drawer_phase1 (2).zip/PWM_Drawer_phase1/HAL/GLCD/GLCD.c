/**
 * @file GLCD.c
 * @brief KS0108 128x64 graphical LCD driver for the PWM Drawer project.
 */
#include "GLCD.h"
#include <avr/io.h>
#include <util/delay.h>
#include "../../MCAL/DIO/DIO.h"

#define GLCD_DI              GPIO_PC2
#define GLCD_RW              GPIO_PC3
#define GLCD_EN              GPIO_PC4
#define GLCD_RST             GPIO_PC5
#define GLCD_CS1             GPIO_PC0
#define GLCD_CS2             GPIO_PC1

static uint8_t glcd_buffer[8][128];

static void GLCD_write(uint8_t data, uint8_t is_data)
{
    *GPIO_GetPORT_FromPin(GPIO_PA0) = data;
    DIO_write_pin(GLCD_DI, is_data ? DIO_HIGH : DIO_LOW);
    DIO_clear_pin(GLCD_RW);
    DIO_set_pin(GLCD_EN);
    _delay_us(1);
    DIO_clear_pin(GLCD_EN);
    _delay_us(1);
}

static void GLCD_command(uint8_t chip, uint8_t command)
{
    DIO_clear_pin(GLCD_CS1);
    DIO_clear_pin(GLCD_CS2);
    DIO_set_pin(chip);
    GLCD_write(command, 0);
}

static void GLCD_data(uint8_t chip, uint8_t data)
{
    DIO_clear_pin(GLCD_CS1);
    DIO_clear_pin(GLCD_CS2);
    DIO_set_pin(chip);
    GLCD_write(data, 1);
}

static void GLCD_character(uint8_t x, uint8_t y, char value)
{
    static const uint8_t digits[10][5] = {
        {0x3E,0x51,0x49,0x45,0x3E},{0x00,0x42,0x7F,0x40,0x00},
        {0x42,0x61,0x51,0x49,0x46},{0x21,0x41,0x45,0x4B,0x31},
        {0x18,0x14,0x12,0x7F,0x10},{0x27,0x45,0x45,0x45,0x39},
        {0x3C,0x4A,0x49,0x49,0x30},{0x01,0x71,0x09,0x05,0x03},
        {0x36,0x49,0x49,0x49,0x36},{0x06,0x49,0x49,0x29,0x1E}
    };
    static const uint8_t glyphs[26][5] = {
        {0x7E,0x11,0x11,0x11,0x7E},{0x7F,0x49,0x49,0x49,0x36},
        {0x3E,0x41,0x41,0x41,0x22},{0x7F,0x41,0x41,0x22,0x1C},
        {0x7F,0x49,0x49,0x49,0x41},{0x7F,0x09,0x09,0x09,0x01},
        {0x3E,0x41,0x49,0x49,0x7A},{0x7F,0x08,0x08,0x08,0x7F},
        {0x00,0x41,0x7F,0x41,0x00},{0x20,0x40,0x41,0x3F,0x01},
        {0x7F,0x08,0x14,0x22,0x41},{0x7F,0x40,0x40,0x40,0x40},
        {0x7F,0x02,0x0C,0x02,0x7F},{0x7F,0x04,0x08,0x10,0x7F},
        {0x3E,0x41,0x41,0x41,0x3E},{0x7F,0x09,0x09,0x09,0x06},
        {0x3E,0x41,0x51,0x21,0x5E},{0x7F,0x09,0x19,0x29,0x46},
        {0x46,0x49,0x49,0x49,0x31},{0x01,0x01,0x7F,0x01,0x01},
        {0x3F,0x40,0x40,0x40,0x3F},{0x1F,0x20,0x40,0x20,0x1F},
        {0x3F,0x40,0x38,0x40,0x3F},{0x63,0x14,0x08,0x14,0x63},
        {0x07,0x08,0x70,0x08,0x07},{0x61,0x51,0x49,0x45,0x43}
    };
    uint8_t i;
    for (i = 0; i < 5; i++) {
        uint8_t column = 0;
        if (value >= '0' && value <= '9') column = digits[value - '0'][i];
        else if (value >= 'a' && value <= 'z') value -= 'a' - 'A';
        if (value >= 'A' && value <= 'Z') column = glyphs[value - 'A'][i];
        else if (value == '%') column = (i == 0 || i == 4) ? 0x63 : (i == 1 || i == 3) ? 0x13 : 0x08;
        else if (value == ':') column = (i == 2) ? 0x36 : 0;
        else if (value == '.') column = (i == 2) ? 0x60 : 0;
        else if (value == '-') column = (i == 2) ? 0x08 : 0;
        GLCD_pixel(x + i, y, column & 1);
        GLCD_pixel(x + i, y + 1, column & 2);
        GLCD_pixel(x + i, y + 2, column & 4);
        GLCD_pixel(x + i, y + 3, column & 8);
        GLCD_pixel(x + i, y + 4, column & 16);
        GLCD_pixel(x + i, y + 5, column & 32);
        GLCD_pixel(x + i, y + 6, column & 64);
    }
}

void GLCD_init(void)
{
    uint8_t pin;
    uint8_t saved_sreg = SREG;
    uint8_t jtag_disable_value;

    /* JTD must be written twice within four CPU cycles on ATmega32A. */
    cli();
    jtag_disable_value = (uint8_t)(MCUCSR | (1 << JTD));
    MCUCSR = jtag_disable_value;
    MCUCSR = jtag_disable_value;
    SREG = saved_sreg;
    for (pin = 0; pin < 8; pin++)
        GPIO_Pin_Mode((GPIO_pin_t)(GPIO_PA0 + pin), GPIO_DIO_OUTPUT);
    GPIO_Pin_Mode(GLCD_DI, GPIO_DIO_OUTPUT);
    GPIO_Pin_Mode(GLCD_RW, GPIO_DIO_OUTPUT);
    GPIO_Pin_Mode(GLCD_EN, GPIO_DIO_OUTPUT);
    GPIO_Pin_Mode(GLCD_RST, GPIO_DIO_OUTPUT);
    GPIO_Pin_Mode(GLCD_CS1, GPIO_DIO_OUTPUT);
    GPIO_Pin_Mode(GLCD_CS2, GPIO_DIO_OUTPUT);
    DIO_clear_pin(GLCD_RST);
    _delay_ms(5);
    DIO_set_pin(GLCD_RST);
    GLCD_command(GLCD_CS1, 0x3F);
    GLCD_command(GLCD_CS2, 0x3F);
    GLCD_clear();
}

void GLCD_clear(void)
{
    uint8_t page, x;
    for (page = 0; page < 8; page++)
        for (x = 0; x < 128; x++) glcd_buffer[page][x] = 0;
}

void GLCD_pixel(uint8_t x, uint8_t y, uint8_t state)
{
    uint8_t mask;
    if (x >= 128 || y >= 64) return;
    mask = (uint8_t)(1 << (y & 7));
    if (state) glcd_buffer[y >> 3][x] |= mask;
    else glcd_buffer[y >> 3][x] &= (uint8_t)~mask;
}

void GLCD_text(uint8_t x, uint8_t y, const char *text)
{
    while (*text && x < 122) {
        uint8_t i;
        GLCD_character(x, y, *text++);
        for (i = 0; i < 6; i++) GLCD_pixel(x + i, y + 7, 0);
        x += 6;
    }
}

void GLCD_number(uint8_t x, uint8_t y, uint32_t value)
{
    char digits[10];
    uint8_t count = 0;
    do { digits[count++] = (char)('0' + (value % 10)); value /= 10; } while (value && count < 10);
    while (count) GLCD_character(x, y, digits[--count]), x += 6;
}

void GLCD_refresh(void)
{
    uint8_t page, x;
    for (page = 0; page < 8; page++) {
        GLCD_command(GLCD_CS1, (uint8_t)(0xB8 | page));
        GLCD_command(GLCD_CS1, 0x40);
        GLCD_command(GLCD_CS2, (uint8_t)(0xB8 | page));
        GLCD_command(GLCD_CS2, 0x40);
        for (x = 0; x < 128; x++) {
            GLCD_data(x < 64 ? GLCD_CS1 : GLCD_CS2, glcd_buffer[page][x]);
        }
    }
}
