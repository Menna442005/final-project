#ifndef GLCD_H
#define GLCD_H

#include <stdint.h>

void GLCD_init(void);
void GLCD_clear(void);
void GLCD_pixel(uint8_t x, uint8_t y, uint8_t state);
void GLCD_text(uint8_t x, uint8_t y, const char *text);
void GLCD_number(uint8_t x, uint8_t y, uint32_t value);
void GLCD_refresh(void);

#endif
