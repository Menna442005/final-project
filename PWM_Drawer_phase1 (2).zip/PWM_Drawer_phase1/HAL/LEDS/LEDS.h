/**
 * @file LEDS.h
 * @brief Board-level interface for the four indicator LEDs.
 *
 * The pin mapping below is the single source of truth for LED connections.
 * All LEDs are treated as active-high outputs.
 */
#ifndef LEDS_H
#define LEDS_H

#include "../../MCAL/DIO/DIO.h"
#include "../../MCAL/GPIO/GPIO.h"


/** @brief Logical identifiers for the board's indicator LEDs. */
typedef enum {
    LED1 = GPIO_PB3,
    LED2 = GPIO_PC2,
    LED3 = GPIO_PC7,
    LED4 = GPIO_PD6
}LEDS_t;

/** @brief Toggle an LED's current output state. @param led LED to toggle. */
void LED_Toggle (LEDS_t led);
/** @brief Turn an active-high LED off. @param led LED to turn off. */
void LED_Off (LEDS_t led);
/** @brief Turn an active-high LED on. @param led LED to turn on. */
void LED_On (LEDS_t led);
/** @brief Configure all LED pins as GPIO outputs. */
void LED_init ();

#endif /* LEDS_H */
