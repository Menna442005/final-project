#ifndef LCD_H
#define LCD_H


#include "../../CONFIG.h"
#include <avr/io.h>
#include <util/delay.h>
#include "../../MCAL/GPIO/GPIO.h"

typedef enum {
LCD_RS  = GPIO_PB1,
LCD_EN = GPIO_PB2,
LCD_D4 = GPIO_PA4,
LCD_D5 = GPIO_PA5,
LCD_D6 = GPIO_PA6,
LCD_D7 = GPIO_PA7,
}LCD_pin_t;

// Core Commands
#define LCD_CLEAR_DISPLAY           0x01
#define LCD_RETURN_HOME             0x02

// Entry Mode Set (Cursor Move Direction)
#define LCD_ENTRY_MODE_DEC          0x04 // Cursor moves left
#define LCD_ENTRY_MODE_DEC_SHIFT    0x05 // Cursor moves left, display shifts
#define LCD_ENTRY_MODE_INC          0x06 // Cursor moves right (Default)
#define LCD_ENTRY_MODE_INC_SHIFT    0x07 // Cursor moves right, display shifts

// Display On/Off Control
#define LCD_DISPLAY_OFF             0x08 
#define LCD_DISPLAY_ON              0x0C // Display ON, Cursor OFF, Blink OFF
#define LCD_DISPLAY_ON_CURSOR       0x0E // Display ON, Cursor ON, Blink OFF
#define LCD_DISPLAY_ON_BLINK        0x0F // Display ON, Cursor ON, Blink ON

// Cursor / Display Shift
#define LCD_MOVE_CURSOR_LEFT        0x10 // Shift cursor left
#define LCD_MOVE_CURSOR_RIGHT       0x14 // Shift cursor right
#define LCD_SHIFT_DISPLAY_LEFT      0x18 // Shift entire display left
#define LCD_SHIFT_DISPLAY_RIGHT     0x1C // Shift entire display right

// Function Set
#define LCD_4BIT_1LINE_5x8          0x20
#define LCD_4BIT_2LINE_5x8          0x28 // Standard 4-bit mode for 16x2
#define LCD_8BIT_1LINE_5x8          0x30
#define LCD_8BIT_2LINE_5x8          0x38 // Standard 8-bit mode for 16x2

// Memory Addresses
#define LCD_CGRAM_START             0x40 // Base address for Custom Characters
#define LCD_DDRAM_START             0x80 // Base address for Display RAM (Line 1)
#define LCD_LINE1                   0x80 // Force cursor to Line 1, Col 1
#define LCD_LINE2                   0xC0 // Force cursor to Line 2, Col 1



void LCD_Enable_Pulse ();
void LCD_Write4Bits(uint8_t data);
void LCD_SendCommand(uint8_t command);
void LCD_Send_Data(uint8_t command);
void LCD_Send_Str (char * str);
void LCD_init();
#endif