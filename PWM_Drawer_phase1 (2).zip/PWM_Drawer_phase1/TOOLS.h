/**
 * @file TOOLS.h
 * @brief Common bit-manipulation utilities for AVR registers.
 *
 * The macros in this file operate directly on register-like lvalues. They are
 * shared by the MCAL drivers to keep register operations short and readable.
 */
#ifndef TOOLS_H
#define TOOLS_H

/** @brief Set one bit in a register without changing the other bits. */
#define SET_BIT(REG,BIT)                ((REG)|=(1<<(BIT)))
/** @brief Clear one bit in a register without changing the other bits. */
#define CLEAR_BIT(REG,BIT)              ((REG)&=~(1<<(BIT)))
/** @brief Write a Boolean value to one bit in a register. */
#define WRITE_BIT(REG,BIT,VALUE)        ((VALUE)? SET_BIT(REG,BIT):CLEAR_BIT(REG,BIT))
/** @brief Read one bit and return its value as either zero or one. */
#define READ_BIT( REG , BIT )           (((REG) >> (BIT)) & 0x01)                                                 
/** @brief Invert one bit in a register without changing the other bits. */
#define TOGGLE_BIT( REG , BIT )         ((REG)^=(1<<(BIT)))

#define GET_LOWER_NIBBLE(REG)            ((REG) & 0x0F)
#define GET_UPPER_NIBBLE(REG)             (((REG) & 0xF0)>>4)

#endif /* TOOLS_H */
